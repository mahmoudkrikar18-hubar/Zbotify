package dev.krikar.zbotify;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Minimal MP4/M4A demuxer that pulls the raw AAC frames + AudioSpecificConfig out of an audio track.
 * Handles both classic files (stsz/stsc/stco) and fragmented/DASH files (moof/trun), which is what
 * YouTube serves. Pure Java, no dependencies.
 */
final class Mp4Aac {
    record Parsed(byte[] asc, int sampleRate, int channels, List<byte[]> frames) {}

    private static final int[] RATES = {96000, 88200, 64000, 48000, 44100, 32000, 24000, 22050, 16000, 12000, 11025, 8000, 7350};

    private record Box(long start, long payload, long end, String type) {}

    private final byte[] d;
    private long audioTrackId = -1;
    private byte[] asc;
    private int entryRate, entryChannels;
    private final List<byte[]> frames = new ArrayList<>();
    private int trexDefaultSize = 0;

    private Mp4Aac(byte[] data) { this.d = data; }

    static Parsed parse(byte[] data) throws IOException {
        Mp4Aac p = new Mp4Aac(data);
        p.run();
        if (p.asc == null || p.frames.isEmpty()) throw new IOException("No AAC audio track found in file");
        int rate = p.entryRate, ch = p.entryChannels;
        // The AudioSpecificConfig is authoritative.
        if (p.asc.length >= 2) {
            int b0 = p.asc[0] & 0xff, b1 = p.asc[1] & 0xff;
            int objType = b0 >> 3;
            int idx = ((b0 & 7) << 1) | (b1 >> 7);
            int cfg;
            if (objType == 31 || idx == 15) { // escape codes: fall back to the sample entry values
                cfg = 0;
            } else {
                cfg = (b1 >> 3) & 0x0f;
                if (idx < RATES.length) rate = RATES[idx];
                if (cfg > 0 && cfg <= 6) ch = cfg; else if (cfg == 7) ch = 8;
            }
        }
        if (rate <= 0) rate = 44100;
        if (ch <= 0) ch = 2;
        return new Parsed(p.asc, rate, ch, p.frames);
    }

    // ---------------------------------------------------------------- boxes
    private long u8(long p) { return d[(int) p] & 0xffL; }
    private long u16(long p) { return (u8(p) << 8) | u8(p + 1); }
    private long u32(long p) { return (u16(p) << 16) | u16(p + 2); }
    private long u64(long p) { return (u32(p) << 32) | u32(p + 4); }

    private List<Box> children(long from, long to) {
        List<Box> out = new ArrayList<>();
        long p = from;
        while (p + 8 <= to) {
            long size = u32(p);
            String type = new String(d, (int) p + 4, 4, java.nio.charset.StandardCharsets.ISO_8859_1);
            long hdr = 8;
            if (size == 1) { size = u64(p + 8); hdr = 16; }
            else if (size == 0) size = to - p;
            if (size < hdr || p + size > to) { if (p + size > to && size >= hdr) size = to - p; else break; }
            out.add(new Box(p, p + hdr, p + size, type));
            p += size;
        }
        return out;
    }

    private void run() {
        List<Box> top = children(0, d.length);
        for (Box b : top) if (b.type.equals("moov")) moov(b);
        for (Box b : top) if (b.type.equals("moof")) moof(b);
    }

    private void moov(Box moov) {
        for (Box b : children(moov.payload, moov.end)) {
            if (b.type.equals("trak")) trak(b);
            else if (b.type.equals("mvex")) {
                for (Box t : children(b.payload, b.end)) {
                    // trex: ver/flags(4) track_ID(4) default_desc(4) default_duration(4) default_size(4)
                    if (t.type.equals("trex") && audioTrackId < 0) trexDefaultSize = (int) u32(t.payload + 16);
                }
            }
        }
    }

    private void trak(Box trak) {
        long tid = -1;
        boolean soun = false;
        Box stbl = null;
        for (Box b : children(trak.payload, trak.end)) {
            if (b.type.equals("tkhd")) {
                int ver = (int) u8(b.payload);
                tid = u32(b.payload + (ver == 1 ? 20 : 12));
            } else if (b.type.equals("mdia")) {
                for (Box m : children(b.payload, b.end)) {
                    if (m.type.equals("hdlr")) {
                        String h = new String(d, (int) m.payload + 8, 4, java.nio.charset.StandardCharsets.ISO_8859_1);
                        soun = h.equals("soun");
                    } else if (m.type.equals("minf")) {
                        for (Box s : children(m.payload, m.end)) if (s.type.equals("stbl")) stbl = s;
                    }
                }
            }
        }
        if (!soun || stbl == null || asc != null) return;

        long[] sizes = null; int fixedSize = 0; long count = 0;
        long[][] stsc = null; long[] chunkOff = null;
        byte[] localAsc = null;
        for (Box b : children(stbl.payload, stbl.end)) {
            switch (b.type) {
                case "stsd" -> localAsc = stsd(b);
                case "stsz" -> {
                    fixedSize = (int) u32(b.payload + 4);
                    count = u32(b.payload + 8);
                    if (fixedSize == 0) {
                        sizes = new long[(int) count];
                        for (int i = 0; i < count; i++) sizes[i] = u32(b.payload + 12 + 4L * i);
                    }
                }
                case "stsc" -> {
                    int n = (int) u32(b.payload + 4);
                    stsc = new long[n][2];
                    for (int i = 0; i < n; i++) {
                        stsc[i][0] = u32(b.payload + 8 + 12L * i);       // first_chunk
                        stsc[i][1] = u32(b.payload + 8 + 12L * i + 4);   // samples_per_chunk
                    }
                }
                case "stco" -> {
                    int n = (int) u32(b.payload + 4);
                    chunkOff = new long[n];
                    for (int i = 0; i < n; i++) chunkOff[i] = u32(b.payload + 8 + 4L * i);
                }
                case "co64" -> {
                    int n = (int) u32(b.payload + 4);
                    chunkOff = new long[n];
                    for (int i = 0; i < n; i++) chunkOff[i] = u64(b.payload + 8 + 8L * i);
                }
                default -> {}
            }
        }
        if (localAsc == null) return;
        asc = localAsc;
        audioTrackId = tid;
        if (stsc != null && chunkOff != null && count > 0) {
            long sample = 0;
            for (int c = 0; c < chunkOff.length && sample < count; c++) {
                long perChunk = 0;
                for (long[] e : stsc) if (e[0] <= c + 1) perChunk = e[1]; else break;
                long off = chunkOff[c];
                for (long s = 0; s < perChunk && sample < count; s++, sample++) {
                    long sz = fixedSize != 0 ? fixedSize : sizes[(int) sample];
                    if (off + sz > d.length) return;
                    frames.add(Arrays.copyOfRange(d, (int) off, (int) (off + sz)));
                    off += sz;
                }
            }
        }
    }

    /** Returns the AudioSpecificConfig of the first mp4a entry, or null. */
    private byte[] stsd(Box stsd) {
        long entryStart = stsd.payload + 8;
        if (entryStart + 8 > stsd.end) return null;
        long entrySize = u32(entryStart);
        String type = new String(d, (int) entryStart + 4, 4, java.nio.charset.StandardCharsets.ISO_8859_1);
        if (!type.equals("mp4a")) return null;
        long p = entryStart + 8;                 // entry payload
        int version = (int) u16(p + 8);
        entryChannels = (int) u16(p + 16);
        entryRate = (int) (u32(p + 24) >> 16);
        long kids = p + 28 + (version == 1 ? 16 : 0);
        long end = Math.min(entryStart + entrySize, stsd.end);
        for (Box b : children(kids, end)) if (b.type.equals("esds")) return esds(b);
        return null;
    }

    private byte[] esds(Box b) {
        long p = b.payload + 4; // version/flags
        while (p < b.end) {
            int tag = (int) u8(p++);
            int len = 0;
            for (int i = 0; i < 4; i++) {
                int x = (int) u8(p++);
                len = (len << 7) | (x & 0x7f);
                if ((x & 0x80) == 0) break;
            }
            if (tag == 0x03) {                      // ES_Descriptor
                int flags = (int) u8(p + 2);
                long q = p + 3;
                if ((flags & 0x80) != 0) q += 2;
                if ((flags & 0x40) != 0) q += 1 + u8(q);
                if ((flags & 0x20) != 0) q += 2;
                p = q;
            } else if (tag == 0x04) {               // DecoderConfigDescriptor
                int objType = (int) u8(p);
                if (objType != 0x40) return null;   // not MPEG-4 AAC
                p += 13;
            } else if (tag == 0x05) {               // DecoderSpecificInfo = AudioSpecificConfig
                if (p + len > b.end) return null;
                return Arrays.copyOfRange(d, (int) p, (int) (p + len));
            } else {
                p += len;
            }
        }
        return null;
    }

    // ---------------------------------------------------------------- fragments
    private void moof(Box moof) {
        for (Box traf : children(moof.payload, moof.end)) {
            if (!traf.type.equals("traf")) continue;
            long trackId = -1, base = moof.start;
            int defSize = trexDefaultSize;
            List<Box> kids = children(traf.payload, traf.end);
            for (Box k : kids) {
                if (!k.type.equals("tfhd")) continue;
                long flags = u32(k.payload) & 0xffffff;
                trackId = u32(k.payload + 4);
                long p = k.payload + 8;
                if ((flags & 0x1) != 0) { base = u64(p); p += 8; }
                if ((flags & 0x2) != 0) p += 4;
                if ((flags & 0x8) != 0) p += 4;
                if ((flags & 0x10) != 0) { defSize = (int) u32(p); p += 4; }
            }
            if (audioTrackId >= 0 && trackId != audioTrackId) continue;
            long cursor = -1;
            for (Box k : kids) {
                if (!k.type.equals("trun")) continue;
                long flags = u32(k.payload) & 0xffffff;
                long n = u32(k.payload + 4);
                long p = k.payload + 8;
                long dataPos;
                if ((flags & 0x1) != 0) { dataPos = base + (int) u32(p); p += 4; }
                else dataPos = cursor >= 0 ? cursor : base;
                if ((flags & 0x4) != 0) p += 4;
                for (long i = 0; i < n; i++) {
                    if ((flags & 0x100) != 0) p += 4;
                    long size = defSize;
                    if ((flags & 0x200) != 0) { size = u32(p); p += 4; }
                    if ((flags & 0x400) != 0) p += 4;
                    if ((flags & 0x800) != 0) p += 4;
                    if (size <= 0 || dataPos + size > d.length) break;
                    frames.add(Arrays.copyOfRange(d, (int) dataPos, (int) (dataPos + size)));
                    dataPos += size;
                }
                cursor = dataPos;
            }
        }
    }
}
