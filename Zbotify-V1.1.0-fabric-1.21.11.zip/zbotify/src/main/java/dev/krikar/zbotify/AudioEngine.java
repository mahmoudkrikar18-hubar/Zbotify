package dev.krikar.zbotify;

import javazoom.jl.decoder.Bitstream;
import javazoom.jl.decoder.Decoder;
import javazoom.jl.decoder.Header;
import javazoom.jl.decoder.SampleBuffer;

import javax.sound.sampled.*;
import java.io.*;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Decodes a whole track to PCM in memory, then streams it on a dedicated thread. Survives GUI changes. */
public final class AudioEngine {
    private static final AudioEngine INSTANCE = new AudioEngine();
    public static AudioEngine get() { return INSTANCE; }

    record Decoded(byte[] pcm, AudioFormat fmt) {}

    private final ExecutorService loader = Executors.newSingleThreadExecutor(r -> {
        Thread t = new Thread(r, "Zbotify-Loader"); t.setDaemon(true); return t; });
    private final List<Track> queue = new CopyOnWriteArrayList<>();
    private volatile int index = -1;
    private volatile long gen = 0;
    private volatile Track current;
    private volatile boolean playing, paused, loading;
    private volatile int pos, total, frameSize = 4;
    private volatile float frameRate = 44100f;
    private volatile int pendingSeek = -1;
    private volatile long baseFrames = 0, lineBase = 0;
    private volatile SourceDataLine line;
    private volatile float volume = 0.8f;
    private volatile String status = "";
    private volatile String loadMsg = "";

    // ---- queue / transport ----
    public void restoreQueue(List<String> sources) {
        queue.clear();
        for (String s : sources) queue.add(Track.fromSource(s));
        index = queue.isEmpty() ? -1 : 0;
    }
    public List<Track> queueSnapshot() { return new ArrayList<>(queue); }
    public void setQueue(List<Track> tracks, int start) { queue.clear(); queue.addAll(tracks); persist(); playIndex(start); }
    public void addToQueue(Track t) { queue.add(t); persist(); }
    /** Adds the track to the end of the queue and starts playing it right away. */
    public void playNow(Track t) { queue.add(t); persist(); playIndex(queue.size() - 1); }
    public void clearQueue() { queue.clear(); index = -1; persist(); }
    private void persist() {
        ZbotifyConfig c = ZbotifyConfig.get();
        c.queue = new ArrayList<>(queue.stream().map(Track::source).toList());
        c.save();
    }
    public void playIndex(int i) {
        int n = queue.size();
        if (n == 0) return;
        index = Math.floorMod(i, n);
        start(queue.get(index));
    }
    public void next() { playIndex(index + 1); }
    public void previous() { if (getPositionSec() > 3) seekTo(0); else playIndex(index - 1); }
    public void toggle() {
        if (current == null) { if (!queue.isEmpty()) playIndex(Math.max(index, 0)); return; }
        if (!playing && !loading) { start(current); return; }
        paused = !paused;
    }
    public synchronized void stop() { gen++; playing = false; paused = false; loading = false; pos = 0; }
    public void shutdown() { stop(); loader.shutdownNow(); }

    public void seekTo(double sec) {
        if (!playing) return;
        long f = (long) (Math.max(0, sec) * frameRate);
        pendingSeek = (int) Math.min(f * frameSize, Math.max(0, total - frameSize));
    }
    public void seekBy(double delta) { seekTo(getPositionSec() + delta); }

    public void setVolume(float v) { volume = Math.max(0f, Math.min(1f, v)); applyVolume(); }
    public float getVolume() { return volume; }
    private void applyVolume() {
        SourceDataLine l = line;
        if (l == null) return;
        try {
            if (l.isControlSupported(FloatControl.Type.MASTER_GAIN)) {
                FloatControl c = (FloatControl) l.getControl(FloatControl.Type.MASTER_GAIN);
                float db = volume <= 0.001f ? c.getMinimum() : (float) (20.0 * Math.log10(volume));
                c.setValue(Math.max(c.getMinimum(), Math.min(c.getMaximum(), db)));
            }
        } catch (Exception ignored) {}
    }

    // ---- state ----
    public Track getCurrent() { return current; }
    public boolean isPlaying() { return playing && !paused; }
    public boolean isLoading() { return loading; }
    public String getStatus() { return status; }
    /** What the loader is doing right now ("Fetching audio from YouTube..."). */
    public String getLoadingMessage() { return loadMsg; }
    public double getDurationSec() { return total <= 0 ? 0 : total / (double) (frameSize * frameRate); }
    public double getPositionSec() {
        SourceDataLine l = line;
        double rate = frameSize * (double) frameRate;
        if (l == null || !playing) return Math.max(0, pos) / rate;
        long frames = baseFrames + Math.max(0L, l.getLongFramePosition() - lineBase);   // frames really played by the device
        long max = total / Math.max(1, frameSize);
        return Math.min(frames, max) / (double) frameRate;
    }

    // ---- internals ----
    private synchronized void start(Track t) {
        final long g = ++gen;
        Lyrics.reset(); current = t; loading = true; playing = false; paused = false; status = ""; loadMsg = "Loading..."; pos = 0; total = 0; pendingSeek = -1;
        Thread lt = new Thread(() -> {
            try {
                if (g != gen) return;
                MediaResolver.Resolved r = MediaResolver.resolve(t, m -> { if (g == gen) loadMsg = m; }, () -> g != gen);
                if (g != gen) return;
                Track shown = t;
                if (!r.track().equals(t)) { shown = r.track(); current = shown; }
                File f = r.file();
                loadMsg = "Decoding...";
                Decoded d = decode(f);
                if (g != gen) return;
                frameSize = d.fmt().getFrameSize();
                frameRate = d.fmt().getFrameRate();
                total = d.pcm().length;
                Lyrics.request(shown, f, getDurationSec());
                loading = false; playing = true; loadMsg = "";
                Thread th = new Thread(() -> play(d, g), "Zbotify-Audio");
                th.setDaemon(true); th.setPriority(Thread.MAX_PRIORITY); th.start();
            } catch (Throwable e) {
                if (g == gen) { loading = false; playing = false; loadMsg = ""; status = "Error: " + e.getMessage(); }
                log(e);
            }
        }, "Zbotify-Loader");
        lt.setDaemon(true); lt.start();
    }

    static void log(Throwable e) {
        try {
            Files.createDirectories(ZbotifyClient.dir());
            StringWriter sw = new StringWriter();
            e.printStackTrace(new PrintWriter(sw));
            Files.writeString(ZbotifyClient.dir().resolve("zbotify.log"), java.time.LocalTime.now() + " " + sw + "\n",
                    java.nio.file.StandardOpenOption.CREATE, java.nio.file.StandardOpenOption.APPEND);
        } catch (Exception ignored) {}
    }

    private Decoded decode(File f) throws Exception {
        byte[] head = new byte[12];
        try (InputStream hs = new FileInputStream(f)) { hs.readNBytes(head, 0, 12); }
        boolean riff = head[0] == 'R' && head[1] == 'I' && head[2] == 'F' && head[3] == 'F';
        if (head[4] == 'f' && head[5] == 't' && head[6] == 'y' && head[7] == 'p')
            return AacSupport.decode(f);   // M4A/AAC (what YouTube serves when ffmpeg is not installed)
        if ((head[0] == 'O' && head[1] == 'g' && head[2] == 'g') || (head[0] == 'f' && head[1] == 'L' && head[2] == 'a'))
            throw new IOException("OGG/FLAC files are not supported. Convert to MP3 or WAV.");
        if (riff || f.getName().toLowerCase().endsWith(".wav")) {
            try (AudioInputStream in = AudioSystem.getAudioInputStream(f)) {
                AudioFormat b = in.getFormat();
                AudioFormat target = new AudioFormat(AudioFormat.Encoding.PCM_SIGNED, b.getSampleRate(), 16,
                        b.getChannels(), b.getChannels() * 2, b.getSampleRate(), false);
                try (AudioInputStream pcm = AudioSystem.getAudioInputStream(target, in)) {
                    byte[] data = pcm.readAllBytes();
                    if (data.length == 0) throw new IOException("WAV file is empty.");
                    return new Decoded(data, target);
                }
            }
        }
        ByteArrayOutputStream out = new ByteArrayOutputStream(1 << 20);
        int rate = 44100, ch = 2, frames = 0;
        boolean first = true;
        try (InputStream is = new BufferedInputStream(new FileInputStream(f))) {
            Bitstream bs = new Bitstream(is);
            Decoder dec = new Decoder();
            while (true) {
                Header h;
                try { h = bs.readFrame(); } catch (Exception ex) { if (frames > 0) break; throw ex; }
                if (h == null) break;
                try {
                    SampleBuffer sb = (SampleBuffer) dec.decodeFrame(h, bs);
                    if (first) { rate = sb.getSampleFrequency(); ch = sb.getChannelCount(); first = false; }
                    short[] s = sb.getBuffer();
                    int len = sb.getBufferLength();
                    byte[] bytes = new byte[len * 2];
                    for (int i = 0; i < len; i++) { bytes[i * 2] = (byte) (s[i] & 0xff); bytes[i * 2 + 1] = (byte) ((s[i] >> 8) & 0xff); }
                    out.write(bytes, 0, bytes.length);
                    frames++;
                } catch (Exception ex) { /* skip a corrupt frame */ }
                bs.closeFrame();
            }
            bs.close();
        }
        if (out.size() == 0) throw new IOException("No audio could be decoded (empty or unsupported MP3).");
        return new Decoded(out.toByteArray(), new AudioFormat(rate, 16, ch, true, false));
    }

    private void play(Decoded d, long g) {
        byte[] pcm = d.pcm();
        int fs = d.fmt().getFrameSize();
        int chunk = fs * 4096;
        try (SourceDataLine l = AudioSystem.getSourceDataLine(d.fmt())) {
            int buf = (int) (d.fmt().getFrameRate() * fs * 1.5); buf -= buf % fs;
            l.open(d.fmt(), buf);
            l.start();
            line = l;
            applyVolume();
            boolean wasPaused = false;
            pos = 0;
            lineBase = l.getLongFramePosition(); baseFrames = 0;
            while (g == gen && pos < pcm.length) {
                if (pendingSeek >= 0) {
                    int s = pendingSeek; pendingSeek = -1;
                    pos = Math.min(Math.max(0, s - (s % fs)), pcm.length);
                    l.flush();
                    lineBase = l.getLongFramePosition(); baseFrames = pos / fs;
                }
                if (paused) {
                    if (!wasPaused) { l.stop(); wasPaused = true; }
                    Thread.sleep(40);
                    continue;
                }
                if (wasPaused) { l.start(); wasPaused = false; }
                int n = Math.min(chunk, pcm.length - pos);
                n -= n % fs;
                if (n <= 0) break;
                l.write(pcm, pos, n);
                pos += n;
            }
            if (g == gen && pos >= pcm.length) l.drain();
        } catch (Throwable e) {
            if (g == gen) status = "Audio error: " + e.getMessage();
        } finally {
            if (line != null && g == gen) line = null;
        }
        if (g == gen) { playing = false; if (status.isEmpty()) next(); }
    }
}
