package dev.krikar.zbotify;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.List;

/**
 * Live song search: your library + the online lyrics database. Pick a result to play it.
 * If the song is not in your library yet, the mod downloads the audio (music folder) and the lyrics (lyrics folder) and plays it.
 */
public class SearchScreen extends Screen {
    private record Row(String label, Track local, Lyrics.Result res) {}

    private static String lastText = "";
    private final Screen parent;
    private TextFieldWidget box;
    private volatile List<Row> rows = List.of();
    private volatile boolean dirty, busy;
    private volatile long typedAt, searchId;
    private int page;
    private volatile String msg = "";   // also written by the download thread

    public SearchScreen(Screen parent) {
        super(Text.literal("Search"));
        this.parent = parent;
        if (lastText.trim().length() > 1) typedAt = System.currentTimeMillis();
    }

    @Override protected void init() {
        int cx = width / 2;
        if (box == null) {
            box = new TextFieldWidget(textRenderer, cx - 150, 28, 300, 20, Text.literal("Search"));
            box.setMaxLength(100);
            box.setPlaceholder(Text.literal("Type a song or artist name..."));
            box.setText(lastText);
            box.setChangedListener(s -> { lastText = s; typedAt = System.currentTimeMillis(); });
        } else box.setX(cx - 150);
        addDrawableChild(box);
        setInitialFocus(box);

        int per = Math.max(2, Math.min(7, (height - 90 - 40) / 22));
        List<Row> all = rows;
        int pages = Math.max(1, (all.size() + per - 1) / per);
        page = Math.max(0, Math.min(page, pages - 1));
        for (int r = 0; r < per; r++) {
            int i = page * per + r;
            if (i >= all.size()) break;
            Row row = all.get(i);
            addDrawableChild(ButtonWidget.builder(Text.literal(textRenderer.trimToWidth(row.label(), 286)), b -> pick(row))
                    .dimensions(cx - 150, 56 + r * 22, 300, 20).build());
        }
        int ny = 56 + per * 22 + 4;
        addDrawableChild(ButtonWidget.builder(Text.literal("< Prev"), b -> { page--; clearAndInit(); }).dimensions(cx - 150, ny, 60, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Next >"), b -> { page++; clearAndInit(); }).dimensions(cx + 90, ny, 60, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Done"), b -> close()).dimensions(cx - 50, height - 26, 100, 20).build());
    }

    private void startSearch(String q) {
        q = q.trim();
        final long id = ++searchId;
        if (q.length() < 2) { rows = List.of(); busy = false; dirty = true; return; }
        busy = true;
        final String query = q;
        Thread th = new Thread(() -> {
            List<Row> out = new ArrayList<>();
            String[] words = query.toLowerCase().split("\\s+");
            for (Track t : new ArrayList<>(Library.tracks)) {
                String lab = t.label().toLowerCase();
                boolean all = true;
                for (String w : words) if (!lab.contains(w)) all = false;
                if (all) out.add(new Row("[Local] " + t.label(), t, null));
            }
            if (id == searchId) { rows = new ArrayList<>(out); dirty = true; }
            // Always offer the typed text itself: the mod searches it on YouTube and downloads the audio.
            String qa = "", qt = query;
            int dash = query.indexOf(" - ");
            if (dash > 0) { qa = query.substring(0, dash).trim(); qt = query.substring(dash + 3).trim(); }
            out.add(new Row("[YouTube] Download & play: " + query, null, new Lyrics.Result(0, qt, qa, "", 0, "", "")));
            if (id == searchId) { rows = new ArrayList<>(out); dirty = true; }
            for (Lyrics.Result r : Lyrics.searchAll(query))
                out.add(new Row("[YouTube + lyrics] " + r.artist() + " - " + r.name() + " (" + Ui.fmt(r.duration()) + ")", null, r));
            if (id == searchId) { rows = out; busy = false; page = 0; dirty = true; }
        }, "Zbotify-Search");
        th.setDaemon(true); th.start();
    }

    private void pick(Row row) {
        AudioEngine e = AudioEngine.get();
        if (row.local() != null) {
            int i = Library.tracks.indexOf(row.local());
            e.setQueue(new ArrayList<>(Library.tracks), Math.max(0, i));
            msg = "Playing: " + row.local().label();
            return;
        }
        Lyrics.Result res = row.res();
        Track match = findLocal(res);
        if (match == null) {
            if (!ZbotifyConfig.get().autoDownload) {
                msg = "Not in your library. Turn on Auto-download in settings, or add the file to the music folder, then search again.";
                return;
            }
            // Not in the library: download the audio into the music folder + the lyrics into the lyrics folder, then play it.
            if (SongDownloader.start(res, s -> msg = s, t -> e.setQueue(new ArrayList<>(Library.tracks), Math.max(0, Library.tracks.indexOf(t)))))
                msg = "Looking for the audio...";
            else msg = "Still downloading the previous song - please wait.";
            return;
        }
        Lyrics.saveForced(match, res);
        e.setQueue(new ArrayList<>(Library.tracks), Library.tracks.indexOf(match));
        msg = "Playing with the lyrics you picked: " + match.label();
    }

    /** The library track that is this search result: same title (ignoring "(Official Audio)" etc.) and, when known, same artist. */
    private static Track findLocal(Lyrics.Result res) {
        String rn = Lyrics.norm(SongDownloader.cleanTitle(res.artist(), res.name()));
        String ra = Lyrics.norm(res.artist());
        if (rn.isEmpty()) return null;
        for (Track t : new ArrayList<>(Library.tracks)) {
            String tn = Lyrics.norm(t.title());
            if (tn.isEmpty()) continue;
            boolean title = tn.equals(rn) || (Math.min(tn.length(), rn.length()) >= 4 && (tn.contains(rn) || rn.contains(tn)));
            if (!title) continue;
            String ta = Lyrics.norm(t.artist());
            boolean artistKnown = !t.artist().equals("Unknown artist") && !ta.isEmpty() && !ra.isEmpty();
            if (artistKnown && !(ta.contains(ra) || ra.contains(ta))) continue;
            return t;
        }
        return null;
    }

    @Override public void render(DrawContext ctx, int mx, int my, float delta) {
        if (typedAt > 0 && System.currentTimeMillis() - typedAt > 350) { typedAt = 0; startSearch(box == null ? "" : box.getText()); }
        if (dirty) { dirty = false; clearAndInit(); }
        super.render(ctx, mx, my, delta);
        int a = ZbotifyConfig.get().accentColor(), cx = width / 2;
        ctx.drawCenteredTextWithShadow(textRenderer, Text.literal("SEARCH SONGS"), cx, 10, a);
        String info = busy ? "Searching..." : (rows.isEmpty() && lastText.trim().length() > 1 ? "No results" : rows.size() + " result(s)");
        ctx.drawCenteredTextWithShadow(textRenderer, Text.literal(info), cx, 18 + 0, 0xFF888888);
        if (!msg.isEmpty()) ctx.drawCenteredTextWithShadow(textRenderer, Text.literal(textRenderer.trimToWidth(msg, width - 20)), cx, height - 50, 0xFFFFFF55);
        ctx.drawCenteredTextWithShadow(textRenderer, Text.literal(ZbotifyConfig.CREDIT), cx, height - 38, a);
    }

    @Override public void close() { client.setScreen(parent); }
}
