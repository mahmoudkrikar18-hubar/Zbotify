package dev.krikar.zbotify;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URI;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Locale;
import java.util.concurrent.Executor;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.function.Consumer;
import java.util.regex.Pattern;

/**
 * Search screen -> "download it for me": finds a full-length MP3 for a song that is not in the library yet,
 * saves it in the music folder as "Artist - Title.mp3", saves the lyrics (lyrics folder + .lrc next to the audio),
 * reloads the library and hands the new track back so it can be played right away.
 */
public final class SongDownloader {
    private static final AtomicBoolean RUNNING = new AtomicBoolean(false);
    /** Library / lyrics / playback touch shared state, so they run on the game thread. Overridable for tests. */
    static volatile Executor mainThread = r -> net.minecraft.client.MinecraftClient.getInstance().execute(r);
    private static final long MAX_BYTES = 60L * 1024 * 1024;
    private static final Pattern NOISE_BRACKETS = Pattern.compile(
            "\\s*[(\\[][^)\\]]*(official|audio|video|lyric|visuali[sz]er|\\bhd\\b|\\bhq\\b|explicit|remaster)[^)\\]]*[)\\]]",
            Pattern.CASE_INSENSITIVE);
    private static final Pattern NOISE_TAIL = Pattern.compile(
            "\\s*[-\u2013|]\\s*(official\\s*)?(music\\s*)?(audio|video|lyrics?|visuali[sz]er)\\s*$", Pattern.CASE_INSENSITIVE);

    private SongDownloader() {}

    public static boolean isBusy() { return RUNNING.get(); }

    /**
     * Starts the download on a background thread.
     * @param status receives progress / result messages (called from the background and the game thread)
     * @param ready  called on the game thread once the track is in the library and its lyrics are saved
     * @return false if another download is still running
     */
    public static boolean start(Lyrics.Result res, Consumer<String> status, Consumer<Track> ready) {
        if (!RUNNING.compareAndSet(false, true)) return false;
        Thread th = new Thread(() -> {
            try { run(res, status, ready); }
            catch (Throwable e) { AudioEngine.log(e); status.accept("Download failed: " + reason(e)); }
            finally { RUNNING.set(false); }
        }, "Zbotify-Download");
        th.setDaemon(true); th.start();
        return true;
    }

    static void run(Lyrics.Result res0, Consumer<String> status, Consumer<Track> ready) throws Exception {
        Lyrics.Result res = res0;
        String artist = res.artist() == null || res.artist().isBlank() ? "Unknown artist" : res.artist().trim();
        String title = cleanTitle(artist, res.name());
        String base = fileBase(artist, title);
        Path dir = ZbotifyClient.musicDir();
        Files.createDirectories(dir);
        Path target = dir.resolve(base + ".mp3");
        if (!(Files.isRegularFile(target) && Files.size(target) > 0)) {
            Path m4a = dir.resolve(base + ".m4a");
            if (Files.isRegularFile(m4a) && Files.size(m4a) > 0) target = m4a;
        }

        String via = "your music folder";
        if (!(Files.isRegularFile(target) && Files.size(target) > 0)) {
            status.accept("Looking for the audio: " + base + " ...");
            Path found = null;
            String ytError = null;
            // 1) yt-dlp (same downloader as pasting a link) - finds almost any song
            try {
                java.io.File got = MediaResolver.downloadBySearch(res.artist(), title, status, () -> false);
                String name = got.getName().toLowerCase(Locale.ROOT);
                Path dest = dir.resolve(base + (name.endsWith(".m4a") || name.endsWith(".mp4") ? ".m4a" : ".mp3"));
                String[] ym = MediaResolver.lastSearchMeta;
                if (ym != null && ("Unknown artist".equals(artist) || res.artist() == null || res.artist().isBlank())) {
                    // user only typed a name: use YouTube's own artist/title for the file name and the lyrics search
                    String na = ym[0].equals("YouTube") ? artist : ym[0];
                    String nt = cleanTitle(na, ym[1]);
                    res = new Lyrics.Result(res.id(), nt, na, res.album(), res.duration(), res.synced(), res.plain());
                    base = fileBase(na, nt);
                    dest = dir.resolve(base + (name.endsWith(".m4a") || name.endsWith(".mp4") ? ".m4a" : ".mp3"));
                }
                Files.copy(got.toPath(), dest, StandardCopyOption.REPLACE_EXISTING);
                found = dest; via = "YouTube";
            } catch (Throwable e) {
                AudioEngine.log(e);
                ytError = e.getMessage();
            }
            if (found == null) {
                status.accept("Could not download it" + (ytError == null || ytError.isBlank() ? "." : ": " + ytError)
                        + " (You can also paste a YouTube link in Settings (O).)");
                return;
            }
            target = found;
        }
        // no lyrics came with the search result: look them up now (LRCLIB etc.) so they are saved next to the song
        if (!res.hasSynced() && !res.hasPlain()) {
            try {
                status.accept("Searching lyrics...");
                Lyrics.Result best = null;
                for (Lyrics.Result r : Lyrics.searchAll(res.artist() + " " + res.name())) {
                    if (r.hasSynced()) { best = r; break; }
                    if (best == null && r.hasPlain()) best = r;
                }
                if (best != null) res = new Lyrics.Result(res.id(), res.name(), res.artist(), res.album(), res.duration(), best.synced(), best.plain());
            } catch (Throwable e) { AudioEngine.log(e); }
        }
        final Lyrics.Result fres = res;
        final String fbase = base;
        final Path playTarget = target;
        final String from = via;
        mainThread.execute(() -> {
            try {
                Library.reload();
                Track t = findTrack(playTarget);
                if (t == null) { status.accept("Downloaded, but the file did not show up in the library."); return; }
                Lyrics.saveDownloaded(t, fres, fbase);
                ready.accept(t);
                status.accept("Playing: " + t.label() + " (from " + from + ")");
            } catch (Throwable e) {
                AudioEngine.log(e);
                status.accept("Download failed: " + reason(e));
            }
        });
    }

    private static void download(String url, Path target, String base, Consumer<String> status) throws Exception {
        Path tmp = target.resolveSibling(base + ".mp3.part");
        try {
            HttpRequest rq = HttpRequest.newBuilder(URI.create(url)).timeout(Duration.ofMinutes(3))
                    .header("User-Agent", AudioSources.USER_AGENT).GET().build();
            HttpResponse<InputStream> r = AudioSources.HTTP.send(rq, HttpResponse.BodyHandlers.ofInputStream());
            if (r.statusCode() != 200) { r.body().close(); throw new IOException("server answered HTTP " + r.statusCode()); }
            long total = r.headers().firstValueAsLong("Content-Length").orElse(-1);
            long got = 0, lastUi = 0;
            try (InputStream in = r.body(); OutputStream out = Files.newOutputStream(tmp)) {
                byte[] buf = new byte[32 * 1024];
                int n;
                while ((n = in.read(buf)) != -1) {
                    out.write(buf, 0, n);
                    got += n;
                    if (got > MAX_BYTES) throw new IOException("file is too large");
                    long now = System.currentTimeMillis();
                    if (now - lastUi > 250) {
                        lastUi = now;
                        status.accept("Downloading " + base + " ... " + mb(got) + (total > 0 ? " / " + mb(total) : ""));
                    }
                }
            }
            checkMp3(tmp);
            Files.move(tmp, target, StandardCopyOption.REPLACE_EXISTING);
        } finally {
            Files.deleteIfExists(tmp);
        }
    }

    /** Refuse HTML error pages, M4A, tiny files... anything the player could not decode. */
    static void checkMp3(Path p) throws IOException {
        long size = Files.size(p);
        if (size < 64 * 1024) throw new IOException("the download was not a full song");
        byte[] h = new byte[12];
        try (InputStream in = Files.newInputStream(p)) { if (in.readNBytes(h, 0, 12) < 12) throw new IOException("empty download"); }
        boolean id3 = h[0] == 'I' && h[1] == 'D' && h[2] == '3';
        boolean sync = (h[0] & 0xFF) == 0xFF && (h[1] & 0xE0) == 0xE0;
        if (h[4] == 'f' && h[5] == 't' && h[6] == 'y' && h[7] == 'p') throw new IOException("the source gave M4A/AAC, not MP3");
        if (!id3 && !sync) throw new IOException("the download was not an MP3 file");
    }

    private static Track findTrack(Path target) {
        for (Track t : new ArrayList<>(Library.tracks)) {
            if (t.isUrl()) continue;
            try { if (Files.isSameFile(Path.of(t.source()), target)) return t; } catch (Exception ignored) {}
        }
        return null;
    }

    // ---------- names ----------
    /** "Lil Tjay - Leaked (Official Audio)" by "Lil Tjay" -> "Leaked". Keeps useful brackets like "(feat. X)" or "(Remix)". */
    static String cleanTitle(String artist, String name) {
        String s = name == null ? "" : name.trim();
        String t = NOISE_BRACKETS.matcher(s).replaceAll("");
        t = NOISE_TAIL.matcher(t).replaceAll("").trim();
        String a = artist == null ? "" : artist.trim();
        if (!a.isEmpty()) {
            String low = t.toLowerCase(Locale.ROOT), pre = a.toLowerCase(Locale.ROOT);
            for (String sep : new String[]{" - ", " \u2013 ", " | ", ": "}) {
                if (low.startsWith(pre + sep)) { t = t.substring(a.length() + sep.length()).trim(); break; }
            }
        }
        t = t.replaceAll("\\s+", " ").trim();
        return t.isEmpty() ? s : t;
    }

    static String fileBase(String artist, String title) {
        return safe(artist, "Unknown artist") + " - " + safe(title, "Unknown title");
    }

    private static String safe(String s, String fallback) {
        String r = s.replaceAll("[\\\\/:*?\"<>|\\p{Cntrl}]", "").replaceAll("\\s+", " ").trim();
        if (r.length() > 80) r = r.substring(0, 80).trim();
        while (r.endsWith(".")) r = r.substring(0, r.length() - 1).trim();
        return r.isEmpty() ? fallback : r;
    }

    private static String mb(long bytes) { return String.format(Locale.ROOT, "%.1f MB", bytes / 1048576.0); }

    private static String reason(Throwable e) {
        String m = e.getMessage();
        return m == null || m.isBlank() ? e.getClass().getSimpleName() : m;
    }
}
