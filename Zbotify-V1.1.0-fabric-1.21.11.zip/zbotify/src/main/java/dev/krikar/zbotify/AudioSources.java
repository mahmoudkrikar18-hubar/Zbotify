package dev.krikar.zbotify;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;

/**
 * Where the mod looks for the audio of a song picked in the search screen.
 * Only sources that legally serve the full track as a plain MP3 are used (no YouTube / Spotify, no DRM bypass).
 * A candidate is accepted only if title + artist match AND its length matches the lyrics (so synced lyrics line up).
 * To add another source, implement {@link Provider} and add it to {@link #PROVIDERS}.
 */
public final class AudioSources {
    /** A downloadable full-length MP3. */
    public record Found(String url, String provider, String title, String artist, double duration) {}

    public interface Provider {
        String name();
        /** @return the best matching full-length track, or null. Throws on network errors. */
        Found find(String artist, String title, double durationSec) throws Exception;
    }

    static final String USER_AGENT = "Zbotify/1.1 (Minecraft mod by Krikar Mahmoud)";
    static final HttpClient HTTP = HttpClient.newBuilder()
            .followRedirects(HttpClient.Redirect.NORMAL).connectTimeout(Duration.ofSeconds(10)).build();

    public static final List<Provider> PROVIDERS = List.of(new Audius());

    private AudioSources() {}

    /** Asks every provider in order; first full-length match wins. Provider errors are logged, not fatal. */
    public static Found find(String artist, String title, double durationSec) {
        for (Provider p : PROVIDERS) {
            try {
                Found f = p.find(artist, title, durationSec);
                if (f != null) return f;
            } catch (Throwable e) { AudioEngine.log(e); }
        }
        return null;
    }

    /** Songs that are really downloadable (free sources only) for a search text. */
    public static List<Found> searchFree(String query) {
        List<Found> out = new ArrayList<>();
        try { out.addAll(new Audius().list(query)); } catch (Throwable e) { AudioEngine.log(e); }
        return out.size() > 15 ? out.subList(0, 15) : out;
    }

    static HttpRequest req(String url) {
        return HttpRequest.newBuilder(URI.create(url)).timeout(Duration.ofSeconds(12))
                .header("User-Agent", USER_AGENT).header("Accept", "application/json").GET().build();
    }

    static String enc(String s) { return URLEncoder.encode(s, StandardCharsets.UTF_8); }

    /** Shared by providers: do the title / artist / duration checks and pick the closest length. */
    static boolean titleMatches(String wanted, String candidate) {
        String w = Lyrics.norm(wanted), c = Lyrics.norm(candidate);
        if (w.length() < 2 || c.length() < 2) return false;
        return c.contains(w) || w.contains(c);
    }

    static boolean artistMatches(String wanted, String... candidates) {
        String w = Lyrics.norm(wanted);
        if (w.isEmpty()) return true;              // unknown artist: don't block on it
        for (String c : candidates) {
            String n = Lyrics.norm(c);
            if (!n.isEmpty() && (n.contains(w) || w.contains(n))) return true;
        }
        return false;
    }

    /** Max difference (seconds) between the audio and the lyrics' song length. */
    static final double DURATION_TOLERANCE = 5.0;

    // ------------------------------------------------------------------ Audius
    /**
     * Audius (audius.co): artist-uploaded music, public API, full-length MP3 streams.
     * GET {base}/v1/tracks/search?query=...&app_name=Zbotify  ->  { data: [ {id,title,duration,user:{name,handle},...} ] }
     * GET {base}/v1/tracks/{id}/stream?app_name=Zbotify       ->  redirect to an MP3
     */
    static final class Audius implements Provider {
        /** Overridable for tests. */
        static volatile String base = "https://api.audius.co";
        private static final String APP = "Zbotify";

        @Override public String name() { return "Audius"; }

        @Override public Found find(String artist, String title, double dur) throws Exception {
            List<String> queries = new ArrayList<>();
            if (artist != null && !artist.isBlank()) queries.add(artist + " " + title);
            queries.add(title);
            for (String q : queries) {
                JsonArray data = search(q);
                Found f = best(data, artist, title, dur);
                if (f != null) return f;
            }
            return null;
        }

        /** Every streamable track for a search text (no title matching): the "[Free]" rows in the search screen. */
        List<Found> list(String q) throws Exception {
            List<Found> out = new ArrayList<>();
            for (JsonElement e : search(q)) {
                if (!e.isJsonObject()) continue;
                JsonObject o = e.getAsJsonObject();
                String id = str(o, "id"), t = str(o, "title");
                if (id.isEmpty() || t.isEmpty()) continue;
                if (o.has("is_streamable") && o.get("is_streamable").isJsonPrimitive() && !o.get("is_streamable").getAsBoolean()) continue;
                if (o.get("access") instanceof JsonObject acc && acc.has("stream") && acc.get("stream").isJsonPrimitive()
                        && !acc.get("stream").getAsBoolean()) continue;
                String uname = "", handle = "";
                if (o.get("user") instanceof JsonObject u) { uname = str(u, "name"); handle = str(u, "handle"); }
                double d = o.has("duration") && o.get("duration").isJsonPrimitive() ? o.get("duration").getAsDouble() : 0;
                out.add(new Found(base + "/v1/tracks/" + id + "/stream?app_name=" + APP, name(), t, uname.isEmpty() ? handle : uname, d));
            }
            return out;
        }

        private JsonArray search(String q) throws Exception {
            HttpResponse<String> r = HTTP.send(req(base + "/v1/tracks/search?query=" + enc(q) + "&app_name=" + APP),
                    HttpResponse.BodyHandlers.ofString());
            if (r.statusCode() != 200) throw new java.io.IOException("Audius search HTTP " + r.statusCode());
            JsonElement root = JsonParser.parseString(r.body());
            if (root.isJsonObject() && root.getAsJsonObject().get("data") instanceof JsonArray a) return a;
            return new JsonArray();
        }

        Found best(JsonArray data, String artist, String title, double dur) {
            Found best = null;
            double bestScore = 1e9;
            for (JsonElement e : data) {
                if (!e.isJsonObject()) continue;
                JsonObject o = e.getAsJsonObject();
                String id = str(o, "id"), t = str(o, "title");
                if (id.isEmpty() || !titleMatches(title, t)) continue;
                if (o.has("is_streamable") && o.get("is_streamable").isJsonPrimitive() && !o.get("is_streamable").getAsBoolean()) continue;
                if (o.get("access") instanceof JsonObject acc && acc.has("stream") && acc.get("stream").isJsonPrimitive()
                        && !acc.get("stream").getAsBoolean()) continue;      // premium / gated: needs a login
                String uname = "", handle = "";
                if (o.get("user") instanceof JsonObject u) { uname = str(u, "name"); handle = str(u, "handle"); }
                if (!artistMatches(artist, uname, handle)) continue;
                double d = o.has("duration") && o.get("duration").isJsonPrimitive() ? o.get("duration").getAsDouble() : 0;
                double diff = dur > 0 && d > 0 ? Math.abs(d - dur) : 0;
                if (dur > 0 && d > 0 && diff > DURATION_TOLERANCE) continue;  // different edit / preview: lyrics would not line up
                if (dur > 0 && d <= 0) continue;                               // length unknown: can't trust the sync
                double score = diff + (Lyrics.norm(t).equals(Lyrics.norm(title)) ? 0 : 1);
                if (score < bestScore) {
                    bestScore = score;
                    best = new Found(base + "/v1/tracks/" + id + "/stream?app_name=" + APP, name(), t, uname.isEmpty() ? handle : uname, d);
                }
            }
            return best;
        }

        private static String str(JsonObject o, String k) {
            JsonElement e = o.get(k);
            return e == null || e.isJsonNull() || !e.isJsonPrimitive() ? "" : e.getAsString();
        }
    }
}
