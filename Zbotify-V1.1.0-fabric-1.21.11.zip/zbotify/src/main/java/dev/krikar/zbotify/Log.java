package dev.krikar.zbotify;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/** Writes to .minecraft/logs/latest.log under the name "Zbotify". */
final class Log {
    static final Logger L = LoggerFactory.getLogger("Zbotify");
    private Log() {}
}
