package dev.krikar.zbotify;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.function.BooleanSupplier;
import java.util.function.Consumer;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Stream;

/**
 * Turns whatever the player was given (local file, direct audio URL, YouTube link, Spotify link) into a
 * local audio file the {@link AudioEngine} can decode.
 *
 * YouTube: yt-dlp (downloaded automatically into .minecraft/zbotify/bin) fetches the audio.
 * Spotify: Spotify streams are DRM-protected and cannot be played directly, so - like spotDL - the track's
 *          artist/title are read from the public Spotify page and the matching audio is fetched from YouTube.
 */
public final class MediaResolver {
    public enum Kind { LOCAL, DIRECT, YOUTUBE, SPOTIFY }
    public record Resolved(File file, Track track) {}

    private static final Pattern YT_ID = Pattern.compile("(?:youtu\\.be/|[?&]v=|/shorts/|/embed/|/live/|/v/)([A-Za-z0-9_-]{11})");
    private static final Pattern SP_REF = Pattern.compile("open\\.spotify\\.com/(?:intl-[a-zA-Z-]+/)?(track|album|playlist|artist|episode|show)/([A-Za-z0-9]+)");
    private static final String UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0 Safari/537.36";
    private static final boolean WINDOWS = System.getProperty("os.name", "").toLowerCase(Locale.ROOT).contains("win");

    private MediaResolver() {}

    // ------------------------------------------------------------------ classification
    public static Kind kind(String src) {
        if (src == null || !(src.startsWith("http://") || src.startsWith("https://"))) return Kind.LOCAL;
        String host;
        try { host = URI.create(src.trim()).getHost(); } catch (Exception e) { host = null; }
        if (host == null) return Kind.DIRECT;
        host = host.toLowerCase(Locale.ROOT);
        if (host.equals("youtu.be") || host.equals("youtube.com") || host.endsWith(".youtube.com")
                || host.equals("youtube-nocookie.com") || host.endsWith(".youtube-nocookie.com")) return Kind.YOUTUBE;
        if (host.equals("open.spotify.com")) return Kind.SPOTIFY;
        return Kind.DIRECT;
    }

    public static boolean isStreamLink(String src) {
        Kind k = kind(src);
        return k == Kind.YOUTUBE || k == Kind.SPOTIFY;
    }

    static String youtubeId(String src) {
        Matcher m = YT_ID.matcher(src);
        return m.find() ? m.group(1) : null;
    }

    /** {type, id} of a Spotify link, or null. */
    static String[] spotifyRef(String src) {
        Matcher m = SP_REF.matcher(src);
        return m.find() ? new String[]{m.group(1), m.group(2)} : null;
    }

    static String key(String src) {
        Kind k = kind(src);
        if (k == Kind.YOUTUBE) { String id = youtubeId(src); return id == null ? null : "yt-" + id; }
        if (k == Kind.SPOTIFY) { String[] r = spotifyRef(src); return r == null ? null : "sp-" + r[1]; }
        return null;
    }

    // ------------------------------------------------------------------ paths / metadata cache
    static Path cacheDir() throws IOException {
        Path p = ZbotifyClient.dir().resolve("cache");
        Files.createDirectories(p);
        return p;
    }

    /** Title/artist remembered from an earlier resolve, or null. */
    public static Track cachedTrack(String src) {
        try {
            String key = key(src);
            if (key == null) return null;
            Path meta = ZbotifyClient.dir().resolve("cache").resolve(key + ".meta");
            if (!Files.isRegularFile(meta)) return null;
            List<String> l = Files.readAllLines(meta, StandardCharsets.UTF_8);
            if (l.size() < 2 || l.get(0).isBlank()) return null;
            return new Track(src, l.get(0), l.get(1));
        } catch (Exception e) { return null; }
    }

    /** What to show before the real title is known. */
    public static Track placeholder(String src) {
        Kind k = kind(src);
        if (k == Kind.YOUTUBE) return new Track(src, "YouTube video " + (youtubeId(src) == null ? "" : youtubeId(src)), "YouTube");
        return new Track(src, "Spotify track", "Spotify");
    }

    private static void saveMeta(String key, String title, String artist) {
        try {
            Files.writeString(cacheDir().resolve(key + ".meta"), title.replace('\n', ' ') + "\n" + artist.replace('\n', ' ') + "\n", StandardCharsets.UTF_8);
        } catch (Exception ignored) {}
    }

    private static Path findCached(String key) {
        try (Stream<Path> s = Files.list(cacheDir())) {
            return s.filter(p -> {
                String n = p.getFileName().toString();
                return n.startsWith(key + ".") && !n.endsWith(".meta") && !n.endsWith(".part") && !n.endsWith(".ytdl")
                        && !n.endsWith(".temp") && Files.isRegularFile(p);
            }).findFirst().orElse(null);
        } catch (Exception e) { return null; }
    }

    // ------------------------------------------------------------------ public entry points
    /** Quick title/artist lookup (no audio download). Saves it for later. May block on the network. */
    public static Track fetchMeta(String src) throws Exception {
        Kind k = kind(src);
        String key = key(src);
        Track t;
        if (k == Kind.YOUTUBE) {
            String json = httpGet("https://www.youtube.com/oembed?format=json&url=" + URLEncoder.encode(src, StandardCharsets.UTF_8));
            t = youtubeTrack(src, jsonString(json, "title"), jsonString(json, "author_name"));
        } else if (k == Kind.SPOTIFY) {
            String[] ref = spotifyRef(src);
            if (ref == null || !ref[0].equals("track"))
                throw new IOException("Only single Spotify track links work (not albums, playlists or artists)");
            t = parseSpotify(src, httpGet("https://open.spotify.com/track/" + ref[1]));
        } else return Track.fromSource(src);
        if (key != null && t != null) saveMeta(key, t.title(), t.artist());
        return t;
    }

    public static Resolved resolve(Track t, Consumer<String> progress, BooleanSupplier cancelled) throws Exception {
        String src = t.source();
        Kind k = kind(src);
        if (k == Kind.LOCAL) return new Resolved(new File(src), t);
        if (k == Kind.DIRECT) return new Resolved(downloadDirect(src, progress), t);
        return resolveStream(t, k, progress, cancelled);
    }

    // ------------------------------------------------------------------ direct URLs
    private static File downloadDirect(String url, Consumer<String> progress) throws Exception {
        String clean = url.contains("?") ? url.substring(0, url.indexOf('?')) : url;
        String lower = clean.toLowerCase(Locale.ROOT);
        String ext = lower.endsWith(".wav") ? ".wav" : lower.endsWith(".m4a") ? ".m4a" : ".mp3";
        Path target = cacheDir().resolve(Integer.toHexString(url.hashCode()) + ext);
        if (Files.exists(target)) return target.toFile();
        progress.accept("Downloading...");
        download(url, target);
        return target.toFile();
    }

    private static void download(String url, Path target) throws Exception {
        Path tmp = target.resolveSibling(target.getFileName() + ".part");
        HttpClient c = HttpClient.newBuilder().followRedirects(HttpClient.Redirect.NORMAL).connectTimeout(Duration.ofSeconds(15)).build();
        HttpResponse<Path> r = c.send(HttpRequest.newBuilder(URI.create(url)).header("User-Agent", UA).timeout(Duration.ofMinutes(10)).GET().build(),
                HttpResponse.BodyHandlers.ofFile(tmp));
        if (r.statusCode() != 200) { Files.deleteIfExists(tmp); throw new IOException("HTTP " + r.statusCode() + " for " + url); }
        Files.move(tmp, target, StandardCopyOption.REPLACE_EXISTING);
    }

    // ------------------------------------------------------------------ YouTube / Spotify
    private static Resolved resolveStream(Track t, Kind k, Consumer<String> progress, BooleanSupplier cancelled) throws Exception {
        String src = t.source();
        String key = key(src);
        if (k == Kind.YOUTUBE && key == null)
            throw new IOException("This YouTube link has no video in it (playlist/channel links aren't supported)");
        if (k == Kind.SPOTIFY && key == null)
            throw new IOException("Only single Spotify track links work (not albums, playlists or artists)");
        if (k == Kind.SPOTIFY && !spotifyRef(src)[0].equals("track"))
            throw new IOException("Only single Spotify track links work (not albums, playlists or artists)");

        Track meta = cachedTrack(src);
        Path hit = findCached(key);
        if (hit != null) return new Resolved(hit.toFile(), meta != null ? meta : t);

        String target;
        boolean keepMeta = false;
        if (k == Kind.YOUTUBE) {
            target = "https://www.youtube.com/watch?v=" + key.substring(3);
        } else {
            if (meta == null) { progress.accept("Reading Spotify track..."); meta = fetchMeta(src); }
            target = "ytsearch1:" + (meta.artist() + " - " + meta.title()).replace("\"", "") + " audio";   // no quotes: Windows mangles them in process args
            keepMeta = true;
        }

        Path exe = ensureYtDlp(progress);
        boolean ours = ZbotifyConfig.get().ytdlpPath == null || ZbotifyConfig.get().ytdlpPath.isBlank();
        progress.accept(k == Kind.YOUTUBE ? "Fetching audio from YouTube..." : "Finding \"" + meta.title() + "\" on YouTube...");
        Run r = runYtDlp(exe, target, key, progress, cancelled);
        if (r.file == null && ours && !cancelled.getAsBoolean()) {
            progress.accept("Updating yt-dlp...");
            try { run(List.of(exe.toString(), "-U"), cancelled, 120); } catch (Exception ignored) {}
            progress.accept(k == Kind.YOUTUBE ? "Fetching audio from YouTube..." : "Finding the song on YouTube...");
            r = runYtDlp(exe, target, key, progress, cancelled);
        }
        if (cancelled.getAsBoolean()) throw new IOException("Cancelled");
        if (r.file == null) throw new IOException(friendlyError(r.error));

        Track out = t;
        if (keepMeta) out = meta;
        else if (r.title != null) {
            out = youtubeTrack(src, r.title, r.artist);
            saveMeta(key, out.title(), out.artist());
        } else if (meta != null) out = meta;
        return new Resolved(r.file.toFile(), out);
    }

    /**
     * Search YouTube for "artist - title" with yt-dlp and download the best audio match into the cache.
     * Used by the search screen so songs can be saved into the music folder. Returns the downloaded file (mp3, or m4a without ffmpeg).
     */
    /** Artist/title yt-dlp reported for the last downloadBySearch (YouTube's own metadata), or null. */
    public static volatile String[] lastSearchMeta;

    public static File downloadBySearch(String artist, String title, Consumer<String> progress, BooleanSupplier cancelled) throws Exception {
        String q = ((artist == null || artist.isBlank() || artist.equals("Unknown artist") ? "" : artist + " - ") + title).replace("\"", "").trim();
        String key = "dl-" + Integer.toHexString(q.toLowerCase(Locale.ROOT).hashCode());
        Path hit = findCached(key);
        if (hit != null) return hit.toFile();
        Path exe = ensureYtDlp(progress);
        boolean ours = ZbotifyConfig.get().ytdlpPath == null || ZbotifyConfig.get().ytdlpPath.isBlank();
        progress.accept("Finding \"" + q + "\" on YouTube...");
        Run r = runYtDlp(exe, "ytsearch1:" + q + " audio", key, progress, cancelled);
        if (r.file == null && ours && !cancelled.getAsBoolean()) {
            progress.accept("Updating yt-dlp...");
            try { run(List.of(exe.toString(), "-U"), cancelled, 120); } catch (Exception ignored) {}
            progress.accept("Finding \"" + q + "\" on YouTube...");
            r = runYtDlp(exe, "ytsearch1:" + q + " audio", key, progress, cancelled);
        }
        if (cancelled.getAsBoolean()) throw new IOException("Cancelled");
        if (r.file == null) throw new IOException(friendlyError(r.error));
        if (r.title != null) { Track yt = youtubeTrack("", r.title, r.artist); lastSearchMeta = new String[]{yt.artist(), yt.title()}; }
        else lastSearchMeta = null;
        return r.file.toFile();
    }

    private static Track youtubeTrack(String src, String title, String author) {
        if (title == null || title.isBlank()) title = "YouTube video";
        String artist = author == null ? "" : author.replaceAll("(?i) - topic$", "").replaceAll("(?i)VEVO$", "").trim();
        int dash = title.indexOf(" - ");
        if (dash > 0 && dash < title.length() - 3) { // "Artist - Song" style uploads
            artist = title.substring(0, dash).trim();
            title = title.substring(dash + 3).trim();
        }
        if (artist.isBlank() || artist.equals("NA")) artist = "YouTube";
        return new Track(src, title, artist);
    }

    private static String friendlyError(String e) {
        if (e == null || e.isBlank()) return "Couldn't fetch the audio (see latest.log)";
        String l = e.toLowerCase(Locale.ROOT);
        if (l.contains("sign in") || l.contains("not a bot") || l.contains("cookies"))
            return "YouTube wants a sign-in. Set \"cookiesBrowser\" (e.g. firefox/chrome/edge) in config/zbotify.json";
        if (l.contains("requested format is not available"))
            return "No usable audio format. Install ffmpeg (or Deno) and try again";
        if (l.contains("video unavailable") || l.contains("private video") || l.contains("not available"))
            return "That video is unavailable";
        if (l.contains("unable to download") || l.contains("urlopen") || l.contains("getaddrinfo") || l.contains("timed out"))
            return "Network problem while fetching audio";
        return e.length() > 150 ? e.substring(0, 150) + "..." : e;
    }

    // ------------------------------------------------------------------ yt-dlp
    private record Run(Path file, String title, String artist, String error) {}

    private static Path binDir() throws IOException {
        Path p = ZbotifyClient.dir().resolve("bin");
        Files.createDirectories(p);
        return p;
    }

    static Path ensureYtDlp(Consumer<String> progress) throws Exception {
        String custom = ZbotifyConfig.get().ytdlpPath;
        if (custom != null && !custom.isBlank()) return Path.of(custom);
        String os = System.getProperty("os.name", "").toLowerCase(Locale.ROOT);
        String arch = System.getProperty("os.arch", "").toLowerCase(Locale.ROOT);
        String asset, local;
        if (WINDOWS) { asset = "yt-dlp.exe"; local = "yt-dlp.exe"; }
        else if (os.contains("mac")) { asset = "yt-dlp_macos"; local = "yt-dlp"; }
        else { asset = (arch.contains("aarch64") || arch.contains("arm64")) ? "yt-dlp_linux_aarch64" : "yt-dlp_linux"; local = "yt-dlp"; }
        Path exe = binDir().resolve(local);
        if (Files.isRegularFile(exe) && Files.size(exe) > 1_000_000) return exe;
        progress.accept("Downloading yt-dlp (one time, ~20 MB)...");
        download("https://github.com/yt-dlp/yt-dlp/releases/latest/download/" + asset, exe);
        exe.toFile().setExecutable(true, false);
        return exe;
    }

    private static Path findOnPath(String name) {
        String path = System.getenv("PATH");
        if (path == null) return null;
        for (String dir : path.split(File.pathSeparator)) {
            if (dir.isBlank()) continue;
            for (String n : WINDOWS ? new String[]{name + ".exe", name + ".cmd"} : new String[]{name}) {
                Path p = Path.of(dir.replace("\"", ""), n);
                if (Files.isRegularFile(p)) return p;
            }
        }
        return null;
    }

    static Path findFfmpeg() {
        try {
            String cfg = ZbotifyConfig.get().ffmpegPath;
            if (cfg != null && !cfg.isBlank() && Files.isRegularFile(Path.of(cfg))) return Path.of(cfg);
            Path local = binDir().resolve(WINDOWS ? "ffmpeg.exe" : "ffmpeg");
            if (Files.isRegularFile(local)) return local;
        } catch (Exception ignored) {}
        return findOnPath("ffmpeg");
    }

    private static Run runYtDlp(Path exe, String target, String key, Consumer<String> progress, BooleanSupplier cancelled) throws Exception {
        Path ffmpeg = findFfmpeg();
        List<String> cmd = new ArrayList<>();
        cmd.add(exe.toString());
        cmd.addAll(List.of("--no-playlist", "--no-warnings", "--no-colors", "--no-mtime", "--no-simulate",
                "--encoding", "utf-8", "--socket-timeout", "20", "--retries", "3"));
        cmd.add("-o"); cmd.add(cacheDir().resolve(key + ".%(ext)s").toString());
        cmd.add("--print"); cmd.add("before_dl:ZBMETA\t%(artist,uploader)s\t%(title)s");
        cmd.add("--print"); cmd.add("after_move:ZBFILE\t%(filepath)s");
        if (ffmpeg != null) {
            // Best quality, converted to mp3 so the built-in decoder can read it.
            cmd.addAll(List.of("-f", "bestaudio/best", "-x", "--audio-format", "mp3", "--audio-quality", "0"));
            cmd.add("--ffmpeg-location"); cmd.add(ffmpeg.toString());
        } else {
            // No ffmpeg: AAC in an m4a container (itag 140) - decoded by the built-in AAC decoder.
            cmd.addAll(List.of("-f", "140/bestaudio[ext=m4a]/bestaudio[acodec^=mp4a]"));
        }
        // yt-dlp needs a JavaScript runtime for full YouTube support. Deno is picked up automatically.
        if (findOnPath("deno") == null) {
            if (findOnPath("node") != null) { cmd.add("--js-runtimes"); cmd.add("node"); }
            else if (findOnPath("bun") != null) { cmd.add("--js-runtimes"); cmd.add("bun"); }
        }
        String browser = ZbotifyConfig.get().cookiesBrowser;
        if (browser != null && !browser.isBlank()) { cmd.add("--cookies-from-browser"); cmd.add(browser.trim()); }
        cmd.add(target);

        List<String> lines = run(cmd, cancelled, 240);
        Path file = null; String title = null, artist = null, error = null;
        for (String line : lines) {
            if (line.startsWith("ZBMETA\t")) {
                String[] p = line.split("\t", 3);
                if (p.length == 3) { artist = p[1]; title = p[2]; }
            } else if (line.startsWith("ZBFILE\t")) {
                file = Path.of(line.substring(7).trim());
            } else if (line.startsWith("ERROR:")) {
                error = line.substring(6).trim().replaceFirst("^\\[[^\\]]+\\]\\s*[A-Za-z0-9_-]*:\\s*", "");
            }
        }
        if (file != null && !Files.isRegularFile(file)) file = null;
        if (file == null) {
            Path c = findCached(key);
            if (c != null) file = c;
        }
        if (file == null) Log.L.warn("yt-dlp failed for {}: {}", target, String.join(" | ", lines));
        return new Run(file, title, artist, error);
    }

    /** Runs a process, returns its combined output lines. Killed on cancel or after the timeout. */
    private static List<String> run(List<String> cmd, BooleanSupplier cancelled, int timeoutSec) throws Exception {
        Process p = new ProcessBuilder(cmd).redirectErrorStream(true).start();
        Thread watchdog = new Thread(() -> {
            long end = System.currentTimeMillis() + timeoutSec * 1000L;
            try {
                while (p.isAlive()) {
                    if (cancelled.getAsBoolean() || System.currentTimeMillis() > end) { killTree(p); return; }
                    Thread.sleep(200);
                }
            } catch (InterruptedException ignored) {}
        }, "Zbotify-Watchdog");
        watchdog.setDaemon(true);
        watchdog.start();
        List<String> lines = new ArrayList<>();
        try (BufferedReader r = new BufferedReader(new InputStreamReader(p.getInputStream(), StandardCharsets.UTF_8))) {
            String line;
            while ((line = r.readLine()) != null) lines.add(line);
        }
        p.waitFor();
        return lines;
    }

    /** yt-dlp's standalone builds start a child process; kill it too or it keeps our pipe open. */
    private static void killTree(Process p) {
        try { p.descendants().forEach(ProcessHandle::destroyForcibly); } catch (Exception ignored) {}
        p.destroyForcibly();
    }

    // ------------------------------------------------------------------ ffmpeg fallback for odd formats
    static File ffmpegToWav(File in) throws Exception {
        Path ff = findFfmpeg();
        if (ff == null) throw new IOException("Unsupported audio format (" + in.getName() + "). Install ffmpeg to play it");
        Path out = cacheDir().resolve(in.getName() + ".wav");
        if (Files.isRegularFile(out)) return out.toFile();
        List<String> lines = run(List.of(ff.toString(), "-y", "-v", "error", "-i", in.getAbsolutePath(), "-vn", "-ac", "2", "-ar", "44100",
                "-f", "wav", out.toString()), () -> false, 180);
        if (!Files.isRegularFile(out)) throw new IOException("ffmpeg could not convert the file: " + String.join(" ", lines));
        return out.toFile();
    }

    // ------------------------------------------------------------------ small HTTP / text helpers
    private static String httpGet(String url) throws Exception {
        HttpClient c = HttpClient.newBuilder().followRedirects(HttpClient.Redirect.NORMAL).connectTimeout(Duration.ofSeconds(10)).build();
        HttpResponse<String> r = c.send(HttpRequest.newBuilder(URI.create(url)).header("User-Agent", UA)
                .header("Accept-Language", "en-US,en;q=0.9").timeout(Duration.ofSeconds(20)).GET().build(),
                HttpResponse.BodyHandlers.ofString(StandardCharsets.UTF_8));
        if (r.statusCode() != 200) throw new IOException("HTTP " + r.statusCode());
        return r.body();
    }

    static Track parseSpotify(String src, String html) throws IOException {
        Matcher tm = Pattern.compile("<title[^>]*>(.*?)</title>", Pattern.DOTALL).matcher(html);
        if (tm.find()) {
            String title = htmlUnescape(tm.group(1)).trim();
            Matcher m = Pattern.compile("^(.+) - [A-Za-z ]*?by (.+?) \\| Spotify$").matcher(title);
            if (m.find()) return new Track(src, m.group(1).trim(), m.group(2).trim());
        }
        Matcher og = Pattern.compile("<meta[^>]+property=\"og:title\"[^>]+content=\"([^\"]*)\"").matcher(html);
        Matcher od = Pattern.compile("<meta[^>]+property=\"og:description\"[^>]+content=\"([^\"]*)\"").matcher(html);
        if (og.find()) {
            String song = htmlUnescape(og.group(1)).trim();
            String artist = "Unknown artist";
            if (od.find()) {
                String first = htmlUnescape(od.group(1)).split(" · ")[0].trim();
                if (!first.isBlank()) artist = first;
            }
            return new Track(src, song, artist);
        }
        throw new IOException("Couldn't read the Spotify track page");
    }

    static String htmlUnescape(String s) {
        Matcher m = Pattern.compile("&#(x?)([0-9a-fA-F]+);").matcher(s);
        StringBuilder sb = new StringBuilder();
        while (m.find()) {
            int cp = Integer.parseInt(m.group(2), m.group(1).isEmpty() ? 10 : 16);
            m.appendReplacement(sb, Matcher.quoteReplacement(new String(Character.toChars(cp))));
        }
        m.appendTail(sb);
        return sb.toString().replace("&quot;", "\"").replace("&lt;", "<").replace("&gt;", ">").replace("&amp;", "&");
    }

    static String jsonString(String json, String key) {
        Matcher m = Pattern.compile("\"" + Pattern.quote(key) + "\"\\s*:\\s*\"((?:[^\"\\\\]|\\\\.)*)\"").matcher(json);
        if (!m.find()) return null;
        String s = m.group(1);
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c != '\\' || i + 1 >= s.length()) { sb.append(c); continue; }
            char n = s.charAt(++i);
            switch (n) {
                case 'n' -> sb.append(' ');
                case 't' -> sb.append(' ');
                case 'u' -> {
                    if (i + 4 < s.length()) { sb.append((char) Integer.parseInt(s.substring(i + 1, i + 5), 16)); i += 4; }
                }
                default -> sb.append(n);
            }
        }
        return sb.toString();
    }
}
