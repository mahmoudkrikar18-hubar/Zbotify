package dev.krikar.zbotify;

import net.sourceforge.jaad.aac.Decoder;
import net.sourceforge.jaad.aac.SampleBuffer;

import javax.sound.sampled.AudioFormat;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.nio.file.Files;

/** Decodes AAC audio inside .m4a/.mp4 files (what YouTube serves) to 16-bit PCM using the bundled JAAD decoder. */
final class AacSupport {
    private AacSupport() {}

    static AudioEngine.Decoded decode(File f) throws Exception {
        Mp4Aac.Parsed p = Mp4Aac.parse(Files.readAllBytes(f.toPath()));
        Decoder dec = new Decoder(p.asc());
        SampleBuffer buf = new SampleBuffer();
        int ch = p.channels(), rate = p.sampleRate();
        ByteArrayOutputStream out = new ByteArrayOutputStream(Math.max(1 << 20, p.frames().size() * ch * 2048));
        boolean checked = false;
        int failed = 0;
        for (byte[] frame : p.frames()) {
            try {
                dec.decodeFrame(frame, buf);
            } catch (Exception e) {
                failed++;
                continue; // skip a damaged frame instead of failing the whole song
            }
            byte[] d = buf.getData();          // big-endian 16-bit PCM
            if (d == null || d.length < 2) continue;
            if (!checked) {                    // HE-AAC (SBR) frames come out at twice the nominal rate
                int perChannel = d.length / 2 / ch;
                if (perChannel >= 2048) rate *= 2;
                checked = true;
            }
            for (int i = 0; i + 1 < d.length; i += 2) { byte t = d[i]; d[i] = d[i + 1]; d[i + 1] = t; }
            out.write(d, 0, d.length - (d.length % (2 * ch)));
        }
        if (failed > 0) Log.L.warn("AAC: skipped {} undecodable frame(s) in {}", failed, f.getName());
        if (out.size() == 0) throw new java.io.IOException("Could not decode the AAC audio");
        return new AudioEngine.Decoded(out.toByteArray(), new AudioFormat(rate, 16, ch, true, false));
    }
}
