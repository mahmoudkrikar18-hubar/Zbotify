package dev.krikar.zbotify;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;

import java.nio.file.Path;

/** Zbotify - Made by Krikar Mahmoud */
public class ZbotifyClient implements ClientModInitializer {
    public static KeyBinding OPEN_SETTINGS, OPEN_PLAYER, OPEN_SEARCH;

    public static Path dir() { return FabricLoader.getInstance().getGameDir().resolve("zbotify"); }
    public static Path musicDir() { return dir().resolve("music"); }

    @Override public void onInitializeClient() {
        ZbotifyConfig cfg = ZbotifyConfig.get();
        Library.reload();
        AudioEngine.get().setVolume(cfg.volume);
        AudioEngine.get().restoreQueue(cfg.queue);

        KeyBinding.Category cat = KeyBinding.Category.create(Identifier.of("zbotify", "keys"));
        OPEN_SETTINGS = KeyBindingHelper.registerKeyBinding(
                new KeyBinding("key.zbotify.settings", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_O, cat));
        OPEN_PLAYER = KeyBindingHelper.registerKeyBinding(
                new KeyBinding("key.zbotify.player", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_M, cat));

        OPEN_SEARCH = KeyBindingHelper.registerKeyBinding(
                new KeyBinding("key.zbotify.search", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_N, cat));
        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            while (OPEN_SETTINGS.wasPressed()) mc.setScreen(new SettingsScreen(mc.currentScreen));
            while (OPEN_SEARCH.wasPressed()) mc.setScreen(new SearchScreen(mc.currentScreen));
            while (OPEN_PLAYER.wasPressed()) mc.setScreen(new MusicScreen(mc.currentScreen));
        });
        InventoryWidget.register();
        LyricsHud.register();
        ClientLifecycleEvents.CLIENT_STOPPING.register(mc -> { ZbotifyConfig.get().save(); AudioEngine.get().shutdown(); });
    }
}
