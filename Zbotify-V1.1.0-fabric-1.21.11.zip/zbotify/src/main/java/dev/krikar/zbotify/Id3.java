package dev.krikar.zbotify;

import java.io.File;
import java.io.RandomAccessFile;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;

/** Minimal ID3v2.3/2.4 + ID3v1 reader: returns {title, artist} (either may be null). */
public final class Id3 {
    public static String[] read(File f) {
        String t = null, a = null;
        try (RandomAccessFile r = new RandomAccessFile(f, "r")) {
            if (r.length() >= 10) {
                byte[] h = new byte[10];
                r.readFully(h);
                if (h[0] == 'I' && h[1] == 'D' && h[2] == '3' && (h[3] == 3 || h[3] == 4)) {
                    int ver = h[3];
                    long end = 10L + sync(h, 6), pos = 10;
                    if ((h[5] & 0x40) != 0) {
                        byte[] eh = new byte[4]; r.seek(10); r.readFully(eh);
                        pos = 10 + (ver == 4 ? sync(eh, 0) : int32(eh, 0) + 4);
                    }
                    while (pos + 10 <= end) {
                        r.seek(pos);
                        byte[] fh = new byte[10];
                        r.readFully(fh);
                        if (fh[0] == 0) break;
                        String id = new String(fh, 0, 4, StandardCharsets.ISO_8859_1);
                        int fs = ver == 4 ? sync(fh, 4) : int32(fh, 4);
                        if (fs <= 0 || pos + 10 + fs > end) break;
                        if (id.equals("TIT2") || id.equals("TPE1")) {
                            byte[] d = new byte[Math.min(fs, 2048)];
                            r.readFully(d);
                            String s = text(d);
                            if (id.equals("TIT2")) t = s; else a = s;
                        }
                        pos += 10 + fs;
                    }
                }
            }
            if ((t == null || a == null) && r.length() >= 128) {
                r.seek(r.length() - 128);
                byte[] b = new byte[128];
                r.readFully(b);
                if (b[0] == 'T' && b[1] == 'A' && b[2] == 'G') {
                    if (t == null) t = new String(b, 3, 30, StandardCharsets.ISO_8859_1);
                    if (a == null) a = new String(b, 33, 30, StandardCharsets.ISO_8859_1);
                }
            }
        } catch (Exception ignored) {}
        return new String[]{blank(t), blank(a)};
    }

    private static int sync(byte[] b, int o) { return ((b[o] & 0x7f) << 21) | ((b[o + 1] & 0x7f) << 14) | ((b[o + 2] & 0x7f) << 7) | (b[o + 3] & 0x7f); }
    private static int int32(byte[] b, int o) { return ((b[o] & 0xff) << 24) | ((b[o + 1] & 0xff) << 16) | ((b[o + 2] & 0xff) << 8) | (b[o + 3] & 0xff); }

    private static String text(byte[] d) {
        if (d.length < 2) return null;
        Charset cs = switch (d[0]) {
            case 1 -> StandardCharsets.UTF_16;
            case 2 -> StandardCharsets.UTF_16BE;
            case 3 -> StandardCharsets.UTF_8;
            default -> StandardCharsets.ISO_8859_1;
        };
        return new String(d, 1, d.length - 1, cs);
    }

    private static String blank(String s) {
        if (s == null) return null;
        s = s.replace("\u0000", " ").trim();
        return s.isEmpty() ? null : s;
    }
}
