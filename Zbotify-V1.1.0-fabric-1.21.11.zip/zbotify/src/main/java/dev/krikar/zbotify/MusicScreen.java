package dev.krikar.zbotify;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.SliderWidget;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.List;

/** Main player: transport, seek bar, volume, library / favorites / queue. Opened with M. */
public class MusicScreen extends Screen {
    private final Screen parent;
    private int page = 0, mode = 0; // mode: 0 library, 1 favorites, 2 queue
    private ProgressSlider progress;
    private ButtonWidget playBtn;

    public MusicScreen(Screen parent) { super(Text.literal("Zbotify")); this.parent = parent; }

    private List<Track> list() {
        ZbotifyConfig c = ZbotifyConfig.get();
        if (mode == 1) return new ArrayList<>(Library.tracks.stream().filter(t -> c.favorites.contains(t.source())).toList());
        if (mode == 2) return AudioEngine.get().queueSnapshot();
        return new ArrayList<>(Library.tracks);
    }

    @Override protected void init() {
        AudioEngine e = AudioEngine.get();
        int cx = width / 2;
        progress = addDrawableChild(new ProgressSlider(cx - 150, 44, 300, 16));
        addDrawableChild(ButtonWidget.builder(Text.literal("|<"), b -> e.previous()).dimensions(cx - 150, 66, 30, 20).build());
        playBtn = addDrawableChild(ButtonWidget.builder(Text.literal(">"), b -> e.toggle()).dimensions(cx - 116, 66, 30, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal(">|"), b -> e.next()).dimensions(cx - 82, 66, 30, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Stop"), b -> e.stop()).dimensions(cx - 48, 66, 44, 20).build());
        addDrawableChild(new Ui.VolumeSlider(cx + 2, 66, 148, 20));

        int rows = Math.max(2, Math.min(6, (height - 96 - 70) / 22));
        List<Track> all = list();
        int pages = Math.max(1, (all.size() + rows - 1) / rows);
        page = Math.max(0, Math.min(page, pages - 1));
        ZbotifyConfig c = ZbotifyConfig.get();
        for (int r = 0; r < rows; r++) {
            int i = page * rows + r;
            if (i >= all.size()) break;
            Track t = all.get(i);
            int y = 96 + r * 22;
            final int idx = i;
            String label = t.label();
            addDrawableChild(ButtonWidget.builder(Text.literal(textRenderer.trimToWidth(label, 214)),
                    b -> { e.setQueue(all, idx); }).dimensions(cx - 150, y, 230, 20).build());
            boolean fav = c.favorites.contains(t.source());
            addDrawableChild(ButtonWidget.builder(Text.literal(fav ? "*" : "-"), b -> {
                if (c.favorites.contains(t.source())) c.favorites.remove(t.source()); else c.favorites.add(t.source());
                c.save(); clearAndInit();
            }).dimensions(cx + 84, y, 30, 20).build());
            addDrawableChild(ButtonWidget.builder(Text.literal(mode == 2 ? "Play" : "+Q"), b -> {
                if (mode == 2) e.playIndex(idx); else { e.addToQueue(t); }
            }).dimensions(cx + 118, y, 32, 20).build());
        }
        int ny = 96 + rows * 22 + 4;
        addDrawableChild(ButtonWidget.builder(Text.literal("< Prev"), b -> { page--; clearAndInit(); }).dimensions(cx - 150, ny, 60, 20).build());
        String[] names = {"Library", "Favorites", "Queue"};
        addDrawableChild(ButtonWidget.builder(Text.literal(names[mode] + " (" + all.size() + ")"),
                b -> { mode = (mode + 1) % 3; page = 0; clearAndInit(); }).dimensions(cx - 84, ny, 168, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Next >"), b -> { page++; clearAndInit(); }).dimensions(cx + 90, ny, 60, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Settings"), b -> client.setScreen(new SettingsScreen(this)))
                .dimensions(cx - 150, height - 26, 80, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Search songs"), b -> client.setScreen(new SearchScreen(this)))
                .dimensions(cx - 60, height - 26, 120, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Done"), b -> close()).dimensions(cx + 70, height - 26, 80, 20).build());
    }

    @Override public void render(DrawContext ctx, int mx, int my, float delta) {
        AudioEngine e = AudioEngine.get();
        progress.sync();
        playBtn.setMessage(Text.literal(e.isPlaying() ? "||" : ">"));
        super.render(ctx, mx, my, delta);
        int a = ZbotifyConfig.get().accentColor();
        ctx.drawCenteredTextWithShadow(textRenderer, Text.literal("ZBOTIFY"), width / 2, 8, a);
        Track t = e.getCurrent();
        String np = t == null ? "Nothing playing - pick a track below" : (e.isLoading() ? e.getLoadingMessage() + " " : "Now playing: ") + t.label();
        if (!e.getStatus().isEmpty()) np = e.getStatus();
        ctx.drawCenteredTextWithShadow(textRenderer, Text.literal(textRenderer.trimToWidth(np, 320)), width / 2, 24, 0xFFFFFFFF);
        if (ZbotifyConfig.get().lyricsEnabled && t != null) {
            String st = Lyrics.status();
            String ly = st.isEmpty() ? Lyrics.current(e.getPositionSec()) : st;
            if (ly != null && !ly.isBlank())
                ctx.drawCenteredTextWithShadow(textRenderer, Text.literal(textRenderer.trimToWidth(ly, 360)), width / 2, 34, st.isEmpty() ? a : 0xFF888888);
        }
        ctx.drawCenteredTextWithShadow(textRenderer, Text.literal(ZbotifyConfig.CREDIT), width / 2, height - 38, a);
    }

    @Override public void removed() { ZbotifyConfig.get().save(); }
    @Override public void close() { client.setScreen(parent); }

    private static class ProgressSlider extends SliderWidget {
        private long lastUser = 0;
        ProgressSlider(int x, int y, int w, int h) { super(x, y, w, h, Text.empty(), 0); updateMessage(); }
        @Override protected void updateMessage() {
            AudioEngine e = AudioEngine.get();
            setMessage(Text.literal(Ui.fmt(e.getPositionSec()) + " / " + Ui.fmt(e.getDurationSec())));
        }
        @Override protected void applyValue() {
            lastUser = System.currentTimeMillis();
            AudioEngine e = AudioEngine.get();
            e.seekTo(value * e.getDurationSec());
        }
        void sync() {
            AudioEngine e = AudioEngine.get();
            if (System.currentTimeMillis() - lastUser > 500) {
                double d = e.getDurationSec();
                value = d > 0 ? Math.min(1.0, e.getPositionSec() / d) : 0;
            }
            updateMessage();
        }
    }
}
