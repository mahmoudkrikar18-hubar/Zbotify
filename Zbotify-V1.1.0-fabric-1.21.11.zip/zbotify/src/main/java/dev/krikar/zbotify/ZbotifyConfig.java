package dev.krikar.zbotify;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

public final class ZbotifyConfig {
    public static final String CREDIT = "Made by Krikar Mahmoud";
    public static final String[] ACCENT_NAMES = {"Cyan", "Magenta", "Lime", "Orange", "Violet", "Crimson", "Gold", "Ice", "Sunset", "Ocean", "Rainbow", "Aurora"};
    public static final int[] ACCENTS  = {0xFF00F0FF, 0xFFFF2BD6, 0xFF39FF14, 0xFFFF9F1C, 0xFFA855F7, 0xFFFF3B3B, 0xFFFFD700, 0xFFBFE9FF, 0xFFFF6B6B, 0xFF00B4DB, 0, 0};
    public static final int[] ACCENTS2 = {0xFF7B61FF, 0xFFFFB3F0, 0xFFF4FF5E, 0xFFFF3D00, 0xFF00F0FF, 0xFFFF9F1C, 0xFFFF5E00, 0xFF5C8DFF, 0xFFFFD36B, 0xFF6A00F4, 0, 0};
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static ZbotifyConfig inst;

    public float volume = 0.8f;
    public boolean widgetEnabled = true;
    public boolean lyricsEnabled = true;
    public boolean hudLyrics = true;
    public boolean autoDownload = true;   // search screen: download songs that are not in the library yet
    public int lyricsCorner = 0;   // 0 TL, 1 TR, 2 BL, 3 BR
    public int lyricsStyle = 2;    // 0 Classic, 1 Neon, 2 Karaoke, 3 Wave, 4 Sky
    public int lyricsScale = 1;    // index into LyricsHud.SCALES
    public int accent = 0;
    public int lyricsOffsetMs = 0; // + shows lyrics later, - earlier
    public List<String> urls = new ArrayList<>();
    public List<String> favorites = new ArrayList<>();
    public List<String> queue = new ArrayList<>();
    /** Optional: full path to your own yt-dlp. Empty = Zbotify downloads and updates its own copy. */
    public String ytdlpPath = "";
    /** Optional: full path to ffmpeg. Empty = look in zbotify/bin and on PATH. */
    public String ffmpegPath = "";
    /** Optional: firefox / chrome / edge / brave... lets yt-dlp reuse your browser's YouTube login if YouTube asks to sign in. */
    public String cookiesBrowser = "";

    private static Path path() { return FabricLoader.getInstance().getConfigDir().resolve("zbotify.json"); }

    public static synchronized ZbotifyConfig get() {
        if (inst == null) {
            try {
                if (Files.exists(path())) inst = GSON.fromJson(Files.readString(path()), ZbotifyConfig.class);
            } catch (Exception ignored) {}
            if (inst == null) inst = new ZbotifyConfig();
            if (inst.urls == null) inst.urls = new ArrayList<>();
            if (inst.favorites == null) inst.favorites = new ArrayList<>();
            if (inst.queue == null) inst.queue = new ArrayList<>();
        }
        return inst;
    }

    public synchronized void save() {
        try { Files.writeString(path(), GSON.toJson(this)); } catch (Exception ignored) {}
    }

    private static int hsv(double deg) { return java.awt.Color.HSBtoRGB((float) ((deg % 360) / 360.0), 0.75f, 1f) | 0xFF000000; }
    private static int mix(int c1, int c2, double t) {
        int r = (int) (((c1 >> 16) & 255) * (1 - t) + ((c2 >> 16) & 255) * t);
        int g = (int) (((c1 >> 8) & 255) * (1 - t) + ((c2 >> 8) & 255) * t);
        int b = (int) ((c1 & 255) * (1 - t) + (c2 & 255) * t);
        return 0xFF000000 | (r << 16) | (g << 8) | b;
    }
    /** Main theme color. Rainbow / Aurora are animated. */
    public int accentColor() {
        int i = Math.floorMod(accent, ACCENTS.length);
        long now = System.currentTimeMillis();
        if (i == 10) return hsv(now / 25.0);
        if (i == 11) return mix(0xFF00FFA3, 0xFFB06CFF, (Math.sin(now / 1500.0) + 1) / 2);
        return ACCENTS[i];
    }
    /** Second theme color (used for gradients). */
    public int accent2Color() {
        int i = Math.floorMod(accent, ACCENTS.length);
        long now = System.currentTimeMillis();
        if (i == 10) return hsv(now / 25.0 + 120);
        if (i == 11) return mix(0xFFB06CFF, 0xFF00FFA3, (Math.sin(now / 1500.0) + 1) / 2);
        return ACCENTS2[i];
    }
    public static int blend(int c1, int c2, double t) { return mix(c1, c2, Math.max(0, Math.min(1, t))); }
}
