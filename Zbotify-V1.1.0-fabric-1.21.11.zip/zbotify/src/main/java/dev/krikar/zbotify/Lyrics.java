package dev.krikar.zbotify;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.io.File;
import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Duration;
import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Automatic lyrics. Order: local cache -> .lrc next to the audio file -> LRCLIB (several parallel queries,
 * ID3 tags + filename guesses + duration matching) -> plain lyrics (spread over the song, approximate).
 */
public final class Lyrics {
    public record Line(long ms, String text) {}
    public record Result(long id, String name, String artist, String album, double duration, String synced, String plain) {
        public boolean hasSynced() { return synced != null && !synced.isBlank(); }
        public boolean hasPlain() { return plain != null && !plain.isBlank(); }
    }
    private record Loaded(String text, boolean plain) {}

    private static volatile List<Line> lines = List.of();
    private static volatile String forSource = "";
    private static volatile String status = "";
    private static final Pattern TAG = Pattern.compile("\\[(\\d+):(\\d+(?:\\.\\d+)?)]");
    private static final String BASE = "https://lrclib.net/api/";
    private static final HttpClient HTTP = HttpClient.newBuilder()
            .followRedirects(HttpClient.Redirect.NORMAL).connectTimeout(Duration.ofSeconds(8)).build();

    public static void reset() { lines = List.of(); status = ""; forSource = ""; }
    public static String status() { return status; }
    private static double adj(double p) { return p + ZbotifyConfig.get().lyricsOffsetMs / 1000.0; }

    // ---------- playback-time accessors ----------
    private static int idx(List<Line> l, long ms) {
        int r = -1;
        for (int i = 0; i < l.size(); i++) { if (l.get(i).ms() <= ms) r = i; else break; }
        return r;
    }
    public static String current(double p) {
        List<Line> l = lines; int i = idx(l, (long) (adj(p) * 1000));
        return i < 0 ? null : l.get(i).text();
    }
    public static String next(double p) {
        List<Line> l = lines; int i = idx(l, (long) (adj(p) * 1000));
        for (int j = i + 1; j < l.size(); j++) if (!l.get(j).text().isBlank()) return l.get(j).text();
        return null;
    }
    public static String prev(double p) {
        List<Line> l = lines; int i = idx(l, (long) (adj(p) * 1000));
        for (int j = i - 1; j >= 0; j--) if (!l.get(j).text().isBlank()) return l.get(j).text();
        return null;
    }
    private static int syl(String w) {
        String x = w.toLowerCase().replaceAll("[^\\p{L}]", "");
        if (x.isEmpty()) return 1;
        int n = 0; boolean prev = false;
        for (char ch : x.toCharArray()) {
            boolean v = "aeiouy\u00e0\u00e2\u00e4\u00e9\u00e8\u00ea\u00eb\u00ee\u00ef\u00f4\u00f6\u00f9\u00fb\u00fc\u00e1\u00ed\u00f3\u00fa".indexOf(ch) >= 0;
            if (v && !prev) n++;
            prev = v;
        }
        if (n == 0) return Math.max(1, (x.length() + 2) / 3);   // non-latin scripts: weight by length
        if (x.endsWith("e") && n > 1 && !x.endsWith("le")) n--;
        return Math.max(1, n);
    }

    /**
     * 0..1 = share of the current line's characters already sung. Words get time in proportion to their syllables,
     * and the line is assumed to be sung in ~0.27 s per syllable (never longer than the gap to the next line),
     * so the highlight moves word by word and stops during instrumental gaps. (Estimated: the free lyrics
     * database only has per-line timestamps.)
     */
    public static double progress(double p) {
        List<Line> l = lines; long ms = (long) (adj(p) * 1000); int i = idx(l, ms);
        if (i < 0) return 0;
        Line ln = l.get(i);
        String text = ln.text();
        if (text.isBlank()) return 0;
        long gap = i + 1 < l.size() ? l.get(i + 1).ms() - ln.ms() : 5000;
        String[] words = text.trim().split("\\s+");
        int[] w = new int[words.length];
        int total = 0;
        for (int k = 0; k < words.length; k++) { w[k] = syl(words[k]); total += w[k]; }
        double dur = Math.max(0.6, Math.min(total * 0.27, gap / 1000.0 * 0.92));
        double s = Math.max(0, Math.min(1, (ms - ln.ms()) / 1000.0 / dur)) * total;
        double acc = 0, chars = 0;
        for (int k = 0; k < words.length; k++) {
            if (s >= acc + w[k]) { chars += words[k].length() + 1; acc += w[k]; }
            else { chars += words[k].length() * (s - acc) / w[k]; break; }
        }
        return Math.min(1.0, chars / text.trim().length());
    }
    public static long age(double p) {
        List<Line> l = lines; long ms = (long) (adj(p) * 1000); int i = idx(l, ms);
        return i < 0 ? 0 : ms - l.get(i).ms();
    }

    // ---------- loading ----------
    public static void request(Track t, File file, double dur) {
        if (!ZbotifyConfig.get().lyricsEnabled) return;
        forSource = t.source(); lines = List.of(); status = "Searching lyrics...";
        Thread th = new Thread(() -> {
            try {
                Loaded l = load(t, file, dur);
                if (!t.source().equals(forSource)) return;
                List<Line> parsed = l == null ? List.of() : (l.plain() ? pseudo(l.text(), dur) : parse(l.text()));
                lines = parsed;
                status = parsed.isEmpty() ? "No lyrics found" : "";
            } catch (Throwable e) {
                if (t.source().equals(forSource)) status = "Lyrics unavailable (offline?)";
                AudioEngine.log(e);
            }
        }, "Zbotify-Lyrics");
        th.setDaemon(true); th.start();
    }

    private static Path cachePath(Track t) {
        return ZbotifyClient.dir().resolve("lyrics").resolve(Integer.toHexString(t.source().hashCode()) + ".lrc");
    }

    /** Remember the lyrics the user picked in the search screen for this track. */
    public static void saveForced(Track t, Result r) {
        try {
            Files.createDirectories(cachePath(t).getParent());
            Files.writeString(cachePath(t), r.hasSynced() ? r.synced() : "#PLAIN\n" + r.plain());
        } catch (Exception e) { AudioEngine.log(e); }
    }

    /**
     * Lyrics for a song the mod just downloaded: the cache the player reads (zbotify/lyrics/<hash>.lrc),
     * a readable copy in the same lyrics folder ("Artist - Title.lrc", or .txt when there is no timing),
     * and - for timed lyrics - a .lrc with the audio's name next to it (the "exact lyrics" sidecar).
     */
    public static void saveDownloaded(Track t, Result r, String baseName) {
        if (!r.hasSynced() && !r.hasPlain()) return;           // instrumental / nothing to save
        saveForced(t, r);
        try {
            Path dir = ZbotifyClient.dir().resolve("lyrics");
            Files.createDirectories(dir);
            if (r.hasSynced()) {
                Files.writeString(dir.resolve(baseName + ".lrc"), r.synced());
                if (!t.isUrl()) Files.writeString(Path.of(t.source()).resolveSibling(baseName + ".lrc"), r.synced());
            } else {
                Files.writeString(dir.resolve(baseName + ".txt"), r.plain());
            }
        } catch (Exception e) { AudioEngine.log(e); }
    }

    private static Loaded load(Track t, File file, double dur) throws Exception {
        Path cache = cachePath(t);
        if (Files.exists(cache)) {
            String s = Files.readString(cache);
            return s.startsWith("#PLAIN\n") ? new Loaded(s.substring(7), true) : new Loaded(s, false);
        }
        if (file != null && !t.isUrl()) {
            String n = file.getName();
            int d = n.lastIndexOf('.');
            File side = new File(file.getParentFile(), (d > 0 ? n.substring(0, d) : n) + ".lrc");
            if (side.exists()) return new Loaded(Files.readString(side.toPath()), false);
        }
        String title = clean(t.title());
        String artist = t.artist().equals("Unknown artist") ? null : clean(t.artist());
        String raw = clean(rawName(t));
        List<String[]> pairs = new ArrayList<>();   // {artist or null, title}
        if (artist != null) { pairs.add(new String[]{artist, title}); pairs.add(new String[]{title, artist}); }
        pairs.add(new String[]{null, title});
        if (!raw.equalsIgnoreCase(title)) pairs.add(new String[]{null, raw});
        if (artist != null) pairs.add(new String[]{null, artist});

        LinkedHashSet<String> urls = new LinkedHashSet<>();
        for (String[] p : pairs) {
            urls.add(BASE + "search?track_name=" + enc(p[1]) + (p[0] != null ? "&artist_name=" + enc(p[0]) : ""));
            urls.add(BASE + "search?q=" + enc((p[0] != null ? p[0] + " " : "") + p[1]));
            if (p[0] != null && dur > 0) urls.add(BASE + "get?track_name=" + enc(p[1]) + "&artist_name=" + enc(p[0]) + "&duration=" + (int) dur);
        }
        List<String> list = new ArrayList<>(urls);
        List<Result> all = toResults(fetchAll(list.subList(0, Math.min(10, list.size()))));

        Result best = pick(all, title, raw, artist, dur, true);
        if (best == null) best = pick(all, title, raw, artist, dur, false);
        Loaded out = null;
        if (best != null) out = best.hasSynced() ? new Loaded(best.synced(), false) : new Loaded(best.plain(), true);
        if (out == null && artist != null) {
            String p = ovh(artist, title);
            if (p == null) p = ovh(title, artist);
            if (p != null) out = new Loaded(p, true);
        }
        if (out != null) {
            Files.createDirectories(cache.getParent());
            Files.writeString(cache, out.plain() ? "#PLAIN\n" + out.text() : out.text());
        }
        return out;
    }

    private static Result pick(List<Result> all, String title, String raw, String artist, double dur, boolean synced) {
        String nt = norm(title), nr = norm(raw), na = artist == null ? "" : norm(artist);
        Result best = null; double bs = 1e9;
        for (Result r : all) {
            if (synced ? !r.hasSynced() : !r.hasPlain()) continue;
            double dd = dur > 0 && r.duration() > 0 ? Math.abs(r.duration() - dur) : 5;
            String rn = norm(r.name());
            boolean tm = !rn.isEmpty() && (rn.contains(nt) || nt.contains(rn) || rn.contains(nr) || nr.contains(rn));
            if (tm ? dd > 15 : dd > 3) continue;
            double score = dd + (tm ? 0 : 40) - (!na.isEmpty() && norm(r.artist()).contains(na) ? 2 : 0);
            if (score < bs) { bs = score; best = r; }
        }
        return best;
    }

    private static String ovh(String artist, String title) {
        try {
            String url = "https://api.lyrics.ovh/v1/" + enc(artist).replace("+", "%20") + "/" + enc(title).replace("+", "%20");
            HttpResponse<String> r = HTTP.send(req(url), HttpResponse.BodyHandlers.ofString());
            if (r.statusCode() != 200) return null;
            JsonElement e = JsonParser.parseString(r.body()).getAsJsonObject().get("lyrics");
            String s = e == null || e.isJsonNull() ? "" : e.getAsString();
            return s.isBlank() ? null : s;
        } catch (Exception e) { return null; }
    }

    // ---------- public search (used by the search screen) ----------
    public static List<Result> searchAll(String q) {
        try {
            List<Result> rs = toResults(fetchAll(List.of(BASE + "search?q=" + enc(q), BASE + "search?track_name=" + enc(q))));
            rs.sort(Comparator.comparing((Result r) -> !r.hasSynced()));
            return rs.size() > 40 ? rs.subList(0, 40) : rs;
        } catch (Exception e) { AudioEngine.log(e); return List.of(); }
    }

    // ---------- helpers ----------
    private static HttpRequest req(String url) {
        return HttpRequest.newBuilder(URI.create(url)).timeout(Duration.ofSeconds(9))
                .header("User-Agent", "Zbotify/1.0 (Minecraft mod by Krikar Mahmoud)").GET().build();
    }

    private static List<JsonObject> fetchAll(List<String> urls) {
        List<CompletableFuture<List<JsonObject>>> fs = new ArrayList<>();
        for (String u : urls) {
            fs.add(HTTP.sendAsync(req(u), HttpResponse.BodyHandlers.ofString()).orTimeout(10, TimeUnit.SECONDS)
                    .thenApply(r -> {
                        List<JsonObject> o = new ArrayList<>();
                        if (r.statusCode() != 200) return o;
                        JsonElement e = JsonParser.parseString(r.body());
                        if (e.isJsonArray()) { for (JsonElement x : (JsonArray) e) if (x.isJsonObject()) o.add(x.getAsJsonObject()); }
                        else if (e.isJsonObject() && e.getAsJsonObject().has("id")) o.add(e.getAsJsonObject());
                        return o;
                    }).exceptionally(ex -> new ArrayList<>()));
        }
        List<JsonObject> out = new ArrayList<>();
        for (CompletableFuture<List<JsonObject>> f : fs) out.addAll(f.join());
        return out;
    }

    private static List<Result> toResults(List<JsonObject> objs) {
        Map<Long, Result> m = new LinkedHashMap<>();
        for (JsonObject o : objs) {
            long id = o.has("id") && !o.get("id").isJsonNull() ? o.get("id").getAsLong() : o.toString().hashCode();
            double d = o.has("duration") && !o.get("duration").isJsonNull() ? o.get("duration").getAsDouble() : 0;
            m.putIfAbsent(id, new Result(id, str(o, "trackName"), str(o, "artistName"), str(o, "albumName"), d,
                    str(o, "syncedLyrics"), str(o, "plainLyrics")));
        }
        return new ArrayList<>(m.values());
    }

    private static String str(JsonObject o, String k) {
        JsonElement e = o.get(k);
        return (e == null || e.isJsonNull()) ? "" : e.getAsString();
    }
    private static String enc(String s) { return URLEncoder.encode(s, StandardCharsets.UTF_8); }
    public static String norm(String s) { return s == null ? "" : s.toLowerCase().replaceAll("[^\\p{L}\\p{N}]", ""); }

    private static String rawName(Track t) {
        String n = t.source();
        int s = Math.max(n.lastIndexOf('/'), n.lastIndexOf('\\'));
        if (s >= 0) n = n.substring(s + 1);
        int d = n.lastIndexOf('.');
        return d > 0 ? n.substring(0, d) : n;
    }

    private static String clean(String s) {
        s = s.replaceAll("\\(.*?\\)|\\[.*?]", " ").replace('_', ' ');
        s = s.replaceAll("(?i)official|video|lyrics|audio|\\bhd\\b|\\bhq\\b|\\bfeat\\.?.*$", " ");
        s = s.replaceAll("^\\d{1,3}[\\s._-]+", "");
        return s.replaceAll("\\s+", " ").trim();
    }

    static List<Line> parse(String lrc) {
        List<Line> out = new ArrayList<>();
        for (String raw : lrc.split("\\r?\\n")) {
            Matcher m = TAG.matcher(raw);
            List<Long> times = new ArrayList<>();
            int end = 0;
            while (m.find() && m.start() == end) {
                times.add((long) ((Integer.parseInt(m.group(1)) * 60 + Double.parseDouble(m.group(2))) * 1000));
                end = m.end();
            }
            if (times.isEmpty()) continue;
            String text = raw.substring(end).trim();
            for (long ms : times) out.add(new Line(ms, text));
        }
        out.sort(Comparator.comparingLong(Line::ms));
        return out;
    }

    /** Plain lyrics have no timestamps: spread the lines over the song (approximate sync). */
    static List<Line> pseudo(String plain, double dur) {
        List<String> ls = new ArrayList<>();
        for (String s : plain.split("\\r?\\n")) { s = s.trim(); if (!s.isEmpty() && !s.matches("^\\[.*]$")) ls.add(s); }
        if (ls.isEmpty()) return List.of();
        if (dur <= 0) dur = 180;
        double start = Math.min(15, dur * 0.08), span = dur - start - dur * 0.06;
        List<Line> out = new ArrayList<>();
        for (int i = 0; i < ls.size(); i++) out.add(new Line((long) ((start + span * i / ls.size()) * 1000), ls.get(i)));
        return out;
    }
}
