package dev.krikar.zbotify;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.Text;

import java.util.function.Supplier;

/** Settings menu (press O): audio, widget, theme, lyrics, sources, about. */
public class SettingsScreen extends Screen {
    private final Screen parent;
    private TextFieldWidget url;
    private String msg = "";

    public SettingsScreen(Screen parent) { super(Text.literal("Zbotify Settings")); this.parent = parent; }

    /** Adds a YouTube / Spotify / direct audio link to the library and optionally starts playing it right away. */
    private void addLink(boolean play) {
        ZbotifyConfig c = ZbotifyConfig.get();
        String u = url.getText().trim();
        if (!Library.isPlayableLink(u)) { msg = "Paste a YouTube or Spotify link (or a direct .mp3/.wav/.m4a link)"; return; }
        if (MediaResolver.kind(u) == MediaResolver.Kind.SPOTIFY) {
            String[] ref = MediaResolver.spotifyRef(u);
            if (ref == null || !ref[0].equals("track")) { msg = "Spotify: only single track links work, not albums/playlists"; return; }
        }
        if (!c.urls.contains(u)) c.urls.add(u);
        c.save();
        Library.reload();
        if (play) {
            AudioEngine.get().playNow(Track.fromSource(u));
            msg = "Starting playback...";
            url.setText("");
        } else {
            msg = "Added. Find it in the player library (M).";
            if (MediaResolver.isStreamLink(u) && MediaResolver.cachedTrack(u) == null) {   // look up the real title in the background
                Thread th = new Thread(() -> {
                    try { MediaResolver.fetchMeta(u); Library.reload(); } catch (Exception ignored) {}
                }, "Zbotify-Meta");
                th.setDaemon(true); th.start();
            }
        }
    }

    private static String onOff(boolean b) { return b ? "ON" : "OFF"; }

    private void btn(int x, int y, Supplier<String> label, Runnable action) {
        addDrawableChild(ButtonWidget.builder(Text.literal(label.get()), b -> { action.run(); b.setMessage(Text.literal(label.get())); })
                .dimensions(x, y, 200, 20).build());
    }

    @Override protected void init() {
        ZbotifyConfig c = ZbotifyConfig.get();
        int cx = width / 2, lx = cx - 205, rx = cx + 5, y = 36;
        // left column: general
        addDrawableChild(new Ui.VolumeSlider(lx, y, 200, 20));
        btn(lx, y + 24, () -> "Inventory widget: " + onOff(c.widgetEnabled), () -> c.widgetEnabled = !c.widgetEnabled);
        btn(lx, y + 48, () -> "Theme color: " + ZbotifyConfig.ACCENT_NAMES[Math.floorMod(c.accent, ZbotifyConfig.ACCENT_NAMES.length)], () -> c.accent = (c.accent + 1) % ZbotifyConfig.ACCENT_NAMES.length);
        addDrawableChild(ButtonWidget.builder(Text.literal("Reload music folder"), b -> {
            Library.reload(); msg = Library.tracks.size() + " track(s) in library";
        }).dimensions(lx, y + 72, 200, 20).build());
        url = addDrawableChild(new TextFieldWidget(textRenderer, lx, y + 100, 200, 20, Text.literal("URL")));
        url.setMaxLength(512);
        url.setPlaceholder(Text.literal("Paste YouTube / Spotify / .mp3 link"));
        addDrawableChild(ButtonWidget.builder(Text.literal("Add to library"), b -> addLink(false))
                .dimensions(lx, y + 124, 98, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Play now"), b -> addLink(true))
                .dimensions(lx + 102, y + 124, 98, 20).build());

        // lyrics sync offset row (left column, under the URL buttons)
        final ButtonWidget[] mid = new ButtonWidget[1];
        java.util.function.Supplier<Text> offText = () -> Text.literal("Lyrics sync: " + (c.lyricsOffsetMs >= 0 ? "+" : "") + String.format("%.1f", c.lyricsOffsetMs / 1000.0) + "s");
        addDrawableChild(ButtonWidget.builder(Text.literal("-"), b -> { c.lyricsOffsetMs -= 100; mid[0].setMessage(offText.get()); })
                .dimensions(lx, y + 148, 40, 20).build());
        mid[0] = addDrawableChild(ButtonWidget.builder(offText.get(), b -> { c.lyricsOffsetMs = 0; b.setMessage(offText.get()); })
                .dimensions(lx + 42, y + 148, 116, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("+"), b -> { c.lyricsOffsetMs += 100; mid[0].setMessage(offText.get()); })
                .dimensions(lx + 160, y + 148, 40, 20).build());

        // right column: lyrics
        btn(rx, y, () -> "Auto lyrics: " + onOff(c.lyricsEnabled), () -> c.lyricsEnabled = !c.lyricsEnabled);
        btn(rx, y + 24, () -> "Lyrics on screen: " + onOff(c.hudLyrics), () -> c.hudLyrics = !c.hudLyrics);
        btn(rx, y + 48, () -> "Position: " + LyricsHud.CORNERS[Math.floorMod(c.lyricsCorner, 4)], () -> c.lyricsCorner = (c.lyricsCorner + 1) % 4);
        btn(rx, y + 72, () -> "Style: " + LyricsHud.STYLES[Math.floorMod(c.lyricsStyle, LyricsHud.STYLES.length)],
                () -> c.lyricsStyle = (c.lyricsStyle + 1) % LyricsHud.STYLES.length);
        btn(rx, y + 96, () -> "Size: " + LyricsHud.SCALES[Math.floorMod(c.lyricsScale, LyricsHud.SCALES.length)] + "x",
                () -> c.lyricsScale = (c.lyricsScale + 1) % LyricsHud.SCALES.length);
        addDrawableChild(ButtonWidget.builder(Text.literal("Search songs & lyrics"), b -> client.setScreen(new SearchScreen(this)))
                .dimensions(rx, y + 124, 200, 20).build());
        btn(rx, y + 148, () -> "Auto-download songs: " + onOff(c.autoDownload), () -> c.autoDownload = !c.autoDownload);
        addDrawableChild(ButtonWidget.builder(Text.literal("Done"), b -> close()).dimensions(cx - 50, height - 26, 100, 20).build());
    }

    @Override public void render(DrawContext ctx, int mx, int my, float delta) {
        super.render(ctx, mx, my, delta);
        int a = ZbotifyConfig.get().accentColor(), cx = width / 2;
        ctx.drawCenteredTextWithShadow(textRenderer, Text.literal("ZBOTIFY SETTINGS"), cx, 14, a);
        int y = Math.min(height - 84, 36 + 148 + 28);
        AudioEngine e = AudioEngine.get();
        boolean err = !e.getStatus().isEmpty();
        String live = err ? e.getStatus() : (e.isLoading() ? e.getLoadingMessage() : "");
        String top = !live.isEmpty() ? live : msg;
        ctx.drawCenteredTextWithShadow(textRenderer, Text.literal(textRenderer.trimToWidth(top, width - 20)), cx, y, err ? 0xFFFF5555 : 0xFFFFFF55);
        ctx.drawCenteredTextWithShadow(textRenderer, Text.literal("Keys: Options > Controls > Zbotify (O settings, M player, N search)"), cx, y + 12, 0xFFAAAAAA);
        ctx.drawCenteredTextWithShadow(textRenderer, Text.literal("Search (N) downloads from YouTube into .minecraft/zbotify/music"), cx, y + 24, 0xFFAAAAAA);
        ctx.drawCenteredTextWithShadow(textRenderer, Text.literal("Links: YouTube + Spotify tracks play via yt-dlp (auto-downloaded on first use)"), cx, y + 36, 0xFFAAAAAA);
        ctx.drawCenteredTextWithShadow(textRenderer, Text.literal(ZbotifyConfig.CREDIT), cx, height - 38, a);
    }

    @Override public void removed() { ZbotifyConfig.get().save(); }
    @Override public void close() { client.setScreen(parent); }
}
