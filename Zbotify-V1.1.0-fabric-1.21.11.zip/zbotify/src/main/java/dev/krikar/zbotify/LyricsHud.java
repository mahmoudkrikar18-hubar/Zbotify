package dev.krikar.zbotify;

import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.util.Identifier;
import org.joml.Matrix3x2fStack;

/** In-game lyrics overlay: 4 corners, 10 styles, word-by-word highlight, theme colors. */
public final class LyricsHud {
    public static final String[] CORNERS = {"Top Left", "Top Right", "Bottom Left", "Bottom Right"};
    public static final String[] STYLES = {"Classic", "Neon", "Karaoke", "Wave", "Sky", "Gradient", "Typewriter", "Pulse", "Glass", "Aurora"};
    public static final float[] SCALES = {1f, 1.5f, 2f, 3f};
    private static final int BW = 220;

    public static void register() {
        HudElementRegistry.attachElementBefore(VanillaHudElements.CHAT, Identifier.of("zbotify", "lyrics"),
                (ctx, tick) -> render(ctx));
    }

    private static int argb(int a, int rgb) { return ((Math.max(0, Math.min(255, a))) << 24) | (rgb & 0xFFFFFF); }

    private static void render(DrawContext ctx) {
        ZbotifyConfig c = ZbotifyConfig.get();
        if (!c.lyricsEnabled || !c.hudLyrics) return;
        AudioEngine e = AudioEngine.get();
        if (e.getCurrent() == null) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        TextRenderer tr = mc.textRenderer;
        double pos = e.getPositionSec();
        String st = Lyrics.status();
        boolean status = !st.isEmpty();
        String cur = status ? st : Lyrics.current(pos);
        if (cur == null || cur.isBlank()) return;

        int style = Math.floorMod(c.lyricsStyle, STYLES.length);
        float s = SCALES[Math.floorMod(c.lyricsScale, SCALES.length)];
        int sw = mc.getWindow().getScaledWidth(), sh = mc.getWindow().getScaledHeight();
        int bh = switch (style) { case 2 -> 40; case 4, 9 -> 58; case 8 -> 38; default -> 26; };
        int corner = Math.floorMod(c.lyricsCorner, 4);
        boolean right = corner == 1 || corner == 3;
        float x = right ? sw - 8 - BW * s : 8;
        float y = corner < 2 ? 8 : sh - 52 - bh * s;
        int align = (style == 4 || style == 8 || style == 9) ? 2 : (right ? 1 : 0);
        int accent = c.accentColor(), accent2 = c.accent2Color();
        long now = System.currentTimeMillis();
        long age = status ? 1000 : Lyrics.age(pos);
        int a = status ? 200 : (int) (255 * Math.min(1.0, 0.35 + age / 300.0));
        double frac = status ? 0 : Lyrics.progress(pos);

        Matrix3x2fStack m = ctx.getMatrices();
        m.pushMatrix();
        m.translate(x, y);
        m.scale(s, s);
        if (status) {
            line(ctx, tr, cur, 0, argb(200, 0x999999), 0, align, 0.9f);
            m.popMatrix();
            return;
        }
        String next = Lyrics.next(pos), prev = Lyrics.prev(pos);
        int dim = argb(150, 0xAAAAAA);
        int gray = argb(a, 0x777777);
        switch (style) {
            case 0 -> {
                line(ctx, tr, cur, 0, argb(a, 0xFFFFFF), 0, align, 1f);
                line(ctx, tr, next, 12, dim, 0, align, 0.85f);
            }
            case 1 -> {
                line(ctx, tr, cur, 0, argb(a, 0xFFFFFF), accent, align, 1.1f);
                line(ctx, tr, next, 13, dim, 0, align, 0.85f);
            }
            case 2 -> {
                line(ctx, tr, prev, 0, argb(90, 0xAAAAAA), 0, align, 0.8f);
                fill(ctx, tr, cur, 11, frac, argb(a, accent), gray, 0, align, 1.25f);
                line(ctx, tr, next, 29, dim, 0, align, 0.8f);
            }
            case 3 -> {
                perChar(ctx, tr, cur, 3, 1.2f, align, frac, 0, now, a, accent, accent2);
                line(ctx, tr, next, 17, dim, 0, align, 0.8f);
            }
            case 4 -> {
                ctx.fillGradient(-6, -4, BW + 6, 54, 0xB00B0B2E, 0xB02A0F4A);
                for (int i = 0; i < 18; i++) {
                    int sx = (i * 47 + 13) % BW, sy = (i * 31 + 7) % 50;
                    int tw = (int) Math.abs(60 + 80 * Math.sin(now / 350.0 + i));
                    ctx.fill(sx, sy, sx + 1, sy + 1, argb(tw, 0xFFFFFF));
                }
                line(ctx, tr, prev, 2, argb(90, 0xCCCCFF), 0, 2, 0.8f);
                fill(ctx, tr, cur, 17, frac, argb(a, 0xFFFFFF), argb(a, 0x8888BB), accent, 2, 1.4f);
                line(ctx, tr, next, 42, argb(130, 0xCCCCFF), 0, 2, 0.8f);
            }
            case 5 -> {
                perChar(ctx, tr, cur, 2, 1.25f, align, frac, 1, now, a, accent, accent2);
                line(ctx, tr, next, 17, dim, 0, align, 0.8f);
            }
            case 6 -> {
                line(ctx, tr, prev, 0, argb(90, 0xAAAAAA), 0, align, 0.8f);
                perChar(ctx, tr, cur, 12, 1.15f, align, frac, 2, now, a, accent, accent2);
            }
            case 7 -> {
                float pulse = 1f + 0.3f * (float) Math.max(0, 1 - age / 350.0);
                fill(ctx, tr, cur, 2, frac, argb(a, accent), gray, accent, align, 1.15f * pulse);
                line(ctx, tr, next, 17, dim, 0, align, 0.8f);
            }
            case 8 -> {
                ctx.fill(-6, -4, BW + 6, 34, 0xA0101018);
                Ui.outline(ctx, -6, -4, BW + 12, 38, accent);
                fill(ctx, tr, cur, 4, frac, argb(a, 0xFFFFFF), gray, 0, 2, 1.1f);
                line(ctx, tr, next, 19, dim, 0, 2, 0.8f);
                ctx.fill(-6, 33, -6 + (int) ((BW + 12) * frac), 34, accent);
            }
            default -> {
                ctx.fillGradient(-6, -4, BW + 6, 54, 0xB0060818, 0xB0101C30);
                int mid = ZbotifyConfig.blend(accent, accent2, 0.5);
                for (int xx = 0; xx < BW; xx += 2) {
                    for (int b = 0; b < 3; b++) {
                        double wv = Math.sin(xx / 22.0 + now / 700.0 + b * 1.9);
                        int yy = (int) (22 + 12 * wv - b * 3);
                        ctx.fill(xx, yy, xx + 2, yy + 4 + b, argb(70, b == 0 ? accent : b == 1 ? accent2 : mid));
                    }
                }
                line(ctx, tr, prev, 2, argb(100, 0xDDDDFF), 0, 2, 0.8f);
                fill(ctx, tr, cur, 19, frac, argb(a, 0xFFFFFF), argb(a, 0x99A0C0), accent, 2, 1.35f);
                line(ctx, tr, next, 42, argb(130, 0xDDDDFF), 0, 2, 0.8f);
            }
        }
        m.popMatrix();
    }

    private static float fit(TextRenderer tr, String t, float mul) {
        return Math.min(mul, BW / (float) Math.max(1, tr.getWidth(t)));
    }

    private static float alignX(TextRenderer tr, String t, float k, int align) {
        float w = tr.getWidth(t) * k;
        return align == 1 ? BW - w : align == 2 ? (BW - w) / 2f : 0;
    }

    private static void glow(DrawContext ctx, TextRenderer tr, String t, int glow) {
        int gc = argb(0x55, glow);
        ctx.drawText(tr, t, -1, 0, gc, false);
        ctx.drawText(tr, t, 1, 0, gc, false);
        ctx.drawText(tr, t, 0, -1, gc, false);
        ctx.drawText(tr, t, 0, 1, gc, false);
    }

    private static void line(DrawContext ctx, TextRenderer tr, String t, float y, int color, int glow, int align, float mul) {
        if (t == null || t.isBlank()) return;
        float k = fit(tr, t, mul);
        Matrix3x2fStack m = ctx.getMatrices();
        m.pushMatrix();
        m.translate(alignX(tr, t, k, align), y);
        m.scale(k, k);
        if (glow != 0) glow(ctx, tr, t, glow);
        ctx.drawText(tr, t, 0, 0, color, true);
        m.popMatrix();
    }

    /** Words already sung are bright, upcoming words are dim. */
    private static void fill(DrawContext ctx, TextRenderer tr, String t, float y, double frac, int sung, int unsung, int glow, int align, float mul) {
        float k = fit(tr, t, mul);
        Matrix3x2fStack m = ctx.getMatrices();
        m.pushMatrix();
        m.translate(alignX(tr, t, k, align), y);
        m.scale(k, k);
        if (glow != 0) glow(ctx, tr, t, glow);
        ctx.drawText(tr, t, 0, 0, unsung, true);
        int n = (int) Math.round(t.length() * frac);
        if (n > 0) ctx.drawText(tr, t.substring(0, Math.min(n, t.length())), 0, 0, sung, false);
        m.popMatrix();
    }

    /** Per-letter styles. mode 0 = wave, 1 = gradient, 2 = typewriter (letters appear as they are sung). */
    private static void perChar(DrawContext ctx, TextRenderer tr, String t, float y, float mul, int align, double frac,
                                int mode, long now, int a, int c1, int c2) {
        float k = fit(tr, t, mul);
        Matrix3x2fStack m = ctx.getMatrices();
        m.pushMatrix();
        m.translate(alignX(tr, t, k, align), y);
        m.scale(k, k);
        int n = (int) Math.round(t.length() * frac), cx = 0, len = Math.max(1, t.length());
        for (int i = 0; i < t.length(); i++) {
            boolean sung = i < n;
            if (mode == 2 && !sung) break;
            String ch = String.valueOf(t.charAt(i));
            float dy = mode == 0 ? (float) Math.sin(now / 180.0 + i * 0.6) * 2f : 0f;
            int col = mode == 0 ? (sung ? argb(a, c1) : argb(a, 0xFFFFFF))
                    : (sung ? argb(a, ZbotifyConfig.blend(c1, c2, i / (double) len)) : argb(a, 0x666677));
            m.pushMatrix();
            m.translate(0f, dy);
            ctx.drawText(tr, ch, cx, 0, col, true);
            m.popMatrix();
            cx += tr.getWidth(ch);
        }
        if (mode == 2 && (now / 400) % 2 == 0) ctx.drawText(tr, "_", cx, 0, argb(a, c2), false);
        m.popMatrix();
    }
}
