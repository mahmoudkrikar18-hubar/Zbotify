package dev.krikar.zbotify;

import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;

public record Track(String source, String title, String artist) {
    public boolean isUrl() { return source.startsWith("http://") || source.startsWith("https://"); }

    public static Track fromSource(String src) {
        if (MediaResolver.isStreamLink(src)) {            // YouTube / Spotify link
            Track known = MediaResolver.cachedTrack(src);
            return known != null ? known : MediaResolver.placeholder(src);
        }
        String name = src;
        int q = name.indexOf('?');
        if (q > 0) name = name.substring(0, q);
        int s = Math.max(name.lastIndexOf('/'), name.lastIndexOf('\\'));
        if (s >= 0) name = name.substring(s + 1);
        int d = name.lastIndexOf('.');
        if (d > 0) name = name.substring(0, d);
        if (src.startsWith("http")) { try { name = URLDecoder.decode(name, StandardCharsets.UTF_8); } catch (Exception ignored) {} }
        String artist = "Unknown artist", title = name;
        int dash = name.indexOf(" - ");
        if (dash > 0) { artist = name.substring(0, dash).trim(); title = name.substring(dash + 3).trim(); }
        if (!src.startsWith("http")) {
            java.io.File f = new java.io.File(src);
            if (f.isFile()) {
                String[] tg = Id3.read(f);
                if (tg[0] != null) title = tg[0];
                if (tg[1] != null) artist = tg[1];
            }
        }
        return new Track(src, title, artist);
    }

    public String label() { return artist + " - " + title; }
}
