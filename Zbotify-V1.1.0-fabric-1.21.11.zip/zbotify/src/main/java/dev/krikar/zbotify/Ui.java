package dev.krikar.zbotify;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.widget.SliderWidget;
import net.minecraft.text.Text;

public final class Ui {
    public static String fmt(double sec) {
        int s = (int) Math.max(0, sec);
        return (s / 60) + ":" + String.format("%02d", s % 60);
    }

    public static void outline(DrawContext c, int x, int y, int w, int h, int color) {
        c.fill(x, y, x + w, y + 1, color);
        c.fill(x, y + h - 1, x + w, y + h, color);
        c.fill(x, y, x + 1, y + h, color);
        c.fill(x + w - 1, y, x + w, y + h, color);
    }

    /** Volume slider shared by the Settings and Player screens. */
    public static class VolumeSlider extends SliderWidget {
        public VolumeSlider(int x, int y, int w, int h) {
            super(x, y, w, h, Text.empty(), ZbotifyConfig.get().volume);
            updateMessage();
        }
        @Override protected void updateMessage() { setMessage(Text.literal("Volume: " + Math.round(value * 100) + "%")); }
        @Override protected void applyValue() {
            AudioEngine.get().setVolume((float) value);
            ZbotifyConfig.get().volume = (float) value;
        }
    }
}
