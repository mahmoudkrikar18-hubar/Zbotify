package dev.krikar.zbotify;

import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.fabricmc.fabric.api.client.screen.v1.Screens;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.ingame.InventoryScreen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.ClickableWidget;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

import java.util.List;

/** Compact neon music widget shown beside the inventory (press E). Placed where it cannot overlap slots. */
public final class InventoryWidget {
    private static final int W = 190, H = 112;

    public static void register() {
        ScreenEvents.AFTER_INIT.register((client, screen, sw, sh) -> {
            if (!(screen instanceof InventoryScreen) || !ZbotifyConfig.get().widgetEnabled) return;
            int invLeft = (sw - 176) / 2, invRight = invLeft + 176;
            int x;
            if (sw - invRight - 8 >= W + 4) x = sw - W - 6;       // right side
            else if (invLeft - 8 >= W + 4) x = 6;                  // left side
            else return;                                           // no room: never overlap slots
            final int fx = x, fy = 6;
            AudioEngine e = AudioEngine.get();
            List<ClickableWidget> btns = Screens.getButtons(screen);
            int by = fy + 58;
            btns.add(ButtonWidget.builder(Text.literal("-10"), b -> e.seekBy(-10)).dimensions(fx + 6, by, 30, 14).build());
            btns.add(ButtonWidget.builder(Text.literal("|<"), b -> e.previous()).dimensions(fx + 40, by, 30, 14).build());
            ButtonWidget play = ButtonWidget.builder(Text.literal(">"), b -> e.toggle()).dimensions(fx + 74, by, 30, 14).build();
            btns.add(play);
            btns.add(ButtonWidget.builder(Text.literal(">|"), b -> e.next()).dimensions(fx + 108, by, 30, 14).build());
            btns.add(ButtonWidget.builder(Text.literal("+10"), b -> e.seekBy(10)).dimensions(fx + 142, by, 30, 14).build());

            ScreenEvents.beforeRender(screen).register((s, ctx, mx, my, dt) -> panel(ctx, fx, fy));
            ScreenEvents.afterRender(screen).register((s, ctx, mx, my, dt) -> {
                play.setMessage(Text.literal(e.isPlaying() ? "||" : ">"));
                info(ctx, client.textRenderer, fx, fy);
            });
        });
    }

    private static void panel(DrawContext c, int x, int y) {
        int a = ZbotifyConfig.get().accentColor();
        c.fill(x, y, x + W, y + H, 0xE0101018);
        Ui.outline(c, x, y, W, H, a);
        c.fill(x + 6, y + 6, x + 34, y + 34, 0xFF1B1B2A);
        Ui.outline(c, x + 6, y + 6, 28, 28, a);
    }

    private static final Identifier LOGO = Identifier.of("zbotify", "textures/gui/logo.png");
    private static final int LOGO_TEX = 128; // assets/zbotify/textures/gui/logo.png is 128x128 (Logo_Zbotify.png)

    private static void info(DrawContext c, TextRenderer tr, int x, int y) {
        AudioEngine e = AudioEngine.get();
        int a = ZbotifyConfig.get().accentColor();
        Track t = e.getCurrent();
        c.drawTexture(RenderPipelines.GUI_TEXTURED, LOGO, x + 7, y + 7, 0f, 0f, 26, 26, LOGO_TEX, LOGO_TEX, LOGO_TEX, LOGO_TEX);
        String title = t == null ? "Nothing playing" : (e.isLoading() ? "Loading... " : "") + t.title();
        String artist = t == null ? "Press M for the library" : t.artist();
        if (!e.getStatus().isEmpty()) artist = e.getStatus();
        c.drawText(tr, tr.trimToWidth(title, W - 46), x + 40, y + 10, 0xFFFFFFFF, true);
        c.drawText(tr, tr.trimToWidth(artist, W - 46), x + 40, y + 22, 0xFFAAAAAA, false);
        double pos = e.getPositionSec(), dur = e.getDurationSec();
        int bw = W - 12;
        c.fill(x + 6, y + 40, x + 6 + bw, y + 44, 0xFF2A2A3A);
        if (dur > 0) c.fill(x + 6, y + 40, x + 6 + (int) (bw * Math.min(1.0, pos / dur)), y + 44, a);
        c.drawText(tr, Ui.fmt(pos), x + 6, y + 47, 0xFFCCCCCC, false);
        String d = Ui.fmt(dur);
        c.drawText(tr, d, x + W - 6 - tr.getWidth(d), y + 47, 0xFFCCCCCC, false);
        if (ZbotifyConfig.get().lyricsEnabled && t != null) {
            String st = Lyrics.status();
            String cur = st.isEmpty() ? Lyrics.current(pos) : st;
            String nx = st.isEmpty() ? Lyrics.next(pos) : null;
            if (cur != null && !cur.isBlank()) {
                String s1 = tr.trimToWidth(cur, W - 12);
                c.drawText(tr, s1, x + (W - tr.getWidth(s1)) / 2, y + 75, st.isEmpty() ? 0xFFFFFFFF : 0xFF888888, st.isEmpty());
            }
            if (nx != null && !nx.equals(cur)) {
                String s2 = tr.trimToWidth(nx, W - 12);
                c.drawText(tr, s2, x + (W - tr.getWidth(s2)) / 2, y + 86, 0xFF777777, false);
            }
        }
        c.drawText(tr, ZbotifyConfig.CREDIT, x + 6, y + 99, a, false);
    }
}
