package dev.krikar.zbotify;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

public final class Library {
    public static final List<Track> tracks = new ArrayList<>();

    /** A direct .mp3/.wav/.m4a link, or a YouTube / Spotify link. */
    public static boolean isPlayableLink(String u) {
        if (u == null || !(u.startsWith("http://") || u.startsWith("https://"))) return false;
        return MediaResolver.isStreamLink(u) || isAudio(u);
    }

    public static boolean isAudio(String name) {
        String n = name.toLowerCase();
        int q = n.indexOf('?');
        if (q > 0) n = n.substring(0, q);
        return n.endsWith(".mp3") || n.endsWith(".wav") || n.endsWith(".m4a");
    }

    public static synchronized void reload() {
        tracks.clear();
        Path dir = ZbotifyClient.musicDir();
        try {
            Files.createDirectories(dir);
            try (Stream<Path> s = Files.walk(dir, 3)) {
                s.filter(Files::isRegularFile).filter(p -> isAudio(p.getFileName().toString())).sorted()
                        .forEach(p -> tracks.add(Track.fromSource(p.toString())));
            }
        } catch (Exception ignored) {}
        for (String u : ZbotifyConfig.get().urls) tracks.add(Track.fromSource(u));
    }
}
