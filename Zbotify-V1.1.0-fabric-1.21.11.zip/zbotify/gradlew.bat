@echo off
setlocal
set GRADLE_VERSION=9.2.1
where gradle >nul 2>nul
if %ERRORLEVEL%==0 (
  gradle %*
  exit /b %ERRORLEVEL%
)
set GRADLE_HOME=%USERPROFILE%\.gradle\zbotify-gradle-%GRADLE_VERSION%
if not exist "%GRADLE_HOME%\bin\gradle.bat" (
  set ZIP=%TEMP%\gradle-%GRADLE_VERSION%-bin.zip
  powershell -NoProfile -ExecutionPolicy Bypass -Command "Invoke-WebRequest -Uri 'https://services.gradle.org/distributions/gradle-%GRADLE_VERSION%-bin.zip' -OutFile '%TEMP%\gradle-%GRADLE_VERSION%-bin.zip'"
  powershell -NoProfile -ExecutionPolicy Bypass -Command "Expand-Archive -Force '%TEMP%\gradle-%GRADLE_VERSION%-bin.zip' '%USERPROFILE%\.gradle\zbotify-gradle-extract'"
  if exist "%USERPROFILE%\.gradle\zbotify-gradle-extract\gradle-%GRADLE_VERSION%" move "%USERPROFILE%\.gradle\zbotify-gradle-extract\gradle-%GRADLE_VERSION%" "%GRADLE_HOME%"
)
call "%GRADLE_HOME%\bin\gradle.bat" %*
exit /b %ERRORLEVEL%
