# Zbotify - Made by Krikar Mahmoud
In-game music player for Minecraft Java 1.21.11 (Fabric, client-side).

## Build
1. Install JDK 21. Open this folder in IntelliJ IDEA (import as Gradle project) or run `gradle build`.
2. Jar appears in `build/libs/zbotify-1.2.1.jar`.
3. Put the jar + Fabric API in `.minecraft/mods`.

If Gradle says a version does not exist, edit `gradle.properties` with the versions from https://fabricmc.net/develop

## Use
- Put .mp3/.wav files in `.minecraft/zbotify/music` (name them `Artist - Title.mp3`).
- **M** player/library, **O** settings (rebind in Controls > Zbotify), **E** inventory shows the widget.
- Direct .mp3/.wav URLs: Settings > Add audio URL. YouTube/Spotify links open in your browser (no DRM bypass).
- **N** search: type a song or artist, pick a result. If it is already in your library it plays with the lyrics you picked.
  If not, and *Auto-download songs* is ON (Settings), the mod finds a full-length MP3, saves it to `.minecraft/zbotify/music/Artist - Title.mp3`,
  saves the lyrics to `.minecraft/zbotify/lyrics/` (plus a `.lrc` next to the song), adds it to your library and plays it.
- Search downloads: the song name is searched on YouTube with yt-dlp and saved to the music folder (Audius is no longer used). A match must have the same title, artist and
  length as the lyrics so the timing lines up. Songs that are not on any source still need the file added to the music folder by hand
  (no YouTube/Spotify ripping, no DRM bypass). To add a source, implement `AudioSources.Provider`.

## v1.2
- Lyrics timing now follows the sound device's real playback position (no more drift). Settings has a **Lyrics sync** -/+ 0.1 s offset (click the middle to reset).
- Word-by-word highlight is estimated from syllables (free lyric data only has per-line times).
- 10 lyric styles (Classic, Neon, Karaoke, Wave, Sky, Gradient, Typewriter, Pulse, Glass, Aurora) and 12 theme colors (incl. animated Rainbow and Aurora).

## v1.2.1
- Search now shows **[Free]** rows first: songs that really exist on a free source (Audius) - click to download, play and get lyrics automatically.
- **[YouTube]** / **[YouTube + lyrics]** rows download the song from YouTube, then fetch lyrics automatically.
