# PROJECT_STATE (v1.3.0 merge: see bottom)
Zbotify | MC 1.21.11 | Fabric (Yarn) | Java 21 | package dev.krikar.zbotify | credit: Made by Krikar Mahmoud
Phases 1-3 done, build OK (v1.0). Round 5 (v1.1, NOT compiled): multi-source lyrics (ID3 tags, .lrc sidecar, parallel LRCLIB queries, lyrics.ovh plain fallback with approximate timing), in-game lyrics HUD (4 corners, 5 styles, word highlight, size) via HudElementRegistry, SearchScreen (key N, live local+lyrics DB search), 2-column settings. Round 6 (v1.1.x, compiled only against stubs, NOT against real MC): SearchScreen now auto-downloads songs that are not in the library (SongDownloader + AudioSources[Audius]) -> music folder, lyrics -> lyrics folder (+ .lrc sidecar), reloads Library, plays; Settings toggle 'Auto-download songs' (config autoDownload, default ON). Not done: in-world sky text and real GLSL shaders (needs world-render rewrite). YouTube/Spotify in-game playback declined (DRM/ToS).
Files: build.gradle, gradle.properties, settings.gradle, fabric.mod.json, lang/en_us.json, README.md,
src: ZbotifyClient, ZbotifyConfig, Track, Library, AudioEngine, Ui, InventoryWidget, MusicScreen, SettingsScreen, SearchScreen, Lyrics, LyricsHud, Id3, SongDownloader, AudioSources.
Deps: JLayer com.googlecode.soundlibs:jlayer:1.0.1.4 (jar-in-jar).
Keys: O settings, M player. Config: config/zbotify.json. Music: .minecraft/zbotify/music.
Verified against docs/mappings: KeyBinding.Category.create(Identifier), ConfirmLinkScreen.open(Screen,String).
Still unverified: SliderWidget ctor/abstract methods, Screens.getButtons, ScreenEvents before/afterRender signatures, gradle.properties versions.
Next: user runs build and pastes the first error; fix only that. Then in-game test (E, O, M).
Missing/optional: album art, lyrics, visualizer, fullscreen player, history, shuffle/repeat.
Known: O/M keys don't fire while another screen is open; widget hidden if window too narrow.
Unverified in round 6: Audius request parameters (search `query`+`app_name`, stream redirect) were written from docs/memory, not tested live; real-MC compile not run.

# v1.3.0 (merge): base = v1.2.1 (lyrics, HUD, search, 1.2.1 AudioEngine play loop = good sound) + v1.1.0 downloader.
Added from 1.1.0: MediaResolver (yt-dlp for YouTube links, Spotify track -> YouTube match), Mp4Aac + AacSupport (JAAD, m4a decode), Log, JAAD dep + Appodeal maven repo in build.gradle, config ytdlpPath/ffmpegPath/cookiesBrowser.
AudioEngine: playback loop untouched; start() now goes through MediaResolver.resolve, m4a decoded via AacSupport, playNow()/getLoadingMessage() added.
Settings (O): paste YouTube/Spotify/.mp3 link -> Add to library / Play now. Search (N): download now tries yt-dlp first (MediaResolver.downloadBySearch), Audius as fallback; saves to zbotify/music as "Artist - Title.mp3|m4a".
NOT compiled (no javac/Maven in the authoring sandbox). First build may need small fixes.
